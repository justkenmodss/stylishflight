package com.imjustkenmods.stylishflying;

import net.minecraft.core.Holder;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

public class FlightArmorItem extends ArmorItem {
   public FlightArmorItem(Holder<ArmorMaterial> material, Type type, Properties properties) {
      super(material, type, properties);
   }

   // onArmorTick was removed in 1.21, so this runs from inventoryTick, only while the chestplate is worn
   @Override
   public void inventoryTick(ItemStack stack, Level world, Entity entity, int slotId, boolean isSelected) {
      super.inventoryTick(stack, world, entity, slotId, isSelected);
      if (entity instanceof Player player && player.getItemBySlot(EquipmentSlot.CHEST) == stack) {
         if (!world.isClientSide() && !player.getAbilities().mayfly) {
            player.getAbilities().mayfly = true;
            player.onUpdateAbilities();
         }
      }
   }
}
