package com.imjustkenmods.stylishflying;

import com.mojang.logging.LogUtils;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.config.ModConfig;
import net.neoforged.neoforge.common.NeoForge;
import org.slf4j.Logger;

@Mod(StylishFlying.MODID)
public class StylishFlying {
   public static final String MODID = "stylishflying";
   public static final Logger LOGGER = LogUtils.getLogger();

   public StylishFlying(IEventBus modEventBus, ModContainer modContainer) {
      modEventBus.addListener(ModNetworking::register);
      modContainer.registerConfig(ModConfig.Type.SERVER, ModConfigManager.SPEC, "stylishflying-server.toml");
      modContainer.registerConfig(ModConfig.Type.CLIENT, ModClientConfig.SPEC, "stylishflying-client.toml");
      ModItems.ITEMS.register(modEventBus);
      ModCreativeTabs.CREATIVE_MODE_TABS.register(modEventBus);
      NeoForge.EVENT_BUS.register(new CommonEventHandler());
      NeoForge.EVENT_BUS.register(new TestConfigCopy());
   }
}
