package com.imjustkenmods.stylishflying;

/** Where on the screen a HUD bar is placed before its x/y offset is added. */
public enum HudAnchor {
   // the bar's original spot next to the hotbar
   HOTBAR,
   TOP_LEFT,
   TOP_CENTER,
   TOP_RIGHT,
   MIDDLE_LEFT,
   CENTER,
   MIDDLE_RIGHT,
   BOTTOM_LEFT,
   BOTTOM_CENTER,
   BOTTOM_RIGHT;

   private static final int MARGIN = 4;

   /** X of the bar's outer frame. Only meaningful for anchors other than HOTBAR. */
   public int frameX(int screenW, int frameW) {
      return switch (this) {
         case TOP_LEFT, MIDDLE_LEFT, BOTTOM_LEFT -> MARGIN;
         case TOP_RIGHT, MIDDLE_RIGHT, BOTTOM_RIGHT -> screenW - MARGIN - frameW;
         default -> (screenW - frameW) / 2;
      };
   }

   /** Y of the bar's outer frame. Only meaningful for anchors other than HOTBAR. */
   public int frameY(int screenH, int frameH) {
      return switch (this) {
         case TOP_LEFT, TOP_CENTER, TOP_RIGHT -> MARGIN;
         case BOTTOM_LEFT, BOTTOM_CENTER, BOTTOM_RIGHT -> screenH - MARGIN - frameH;
         default -> (screenH - frameH) / 2;
      };
   }
}
