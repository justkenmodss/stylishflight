package com.imjustkenmods.stylishflying;

import io.netty.buffer.ByteBuf;
import java.util.UUID;
import net.minecraft.core.UUIDUtil;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Player;
import net.neoforged.neoforge.network.handling.IPayloadContext;

public record ClientboundSyncFlightPacket(UUID uuid, boolean flying) implements CustomPacketPayload {
   public static final Type<ClientboundSyncFlightPacket> TYPE = new Type<>(ResourceLocation.fromNamespaceAndPath(StylishFlying.MODID, "sync_flight"));
   public static final StreamCodec<ByteBuf, ClientboundSyncFlightPacket> STREAM_CODEC = StreamCodec.composite(
      UUIDUtil.STREAM_CODEC, ClientboundSyncFlightPacket::uuid,
      ByteBufCodecs.BOOL, ClientboundSyncFlightPacket::flying,
      ClientboundSyncFlightPacket::new
   );

   @Override
   public Type<ClientboundSyncFlightPacket> type() {
      return TYPE;
   }

   public static void handle(ClientboundSyncFlightPacket packet, IPayloadContext context) {
      Player p = context.player().level().getPlayerByUUID(packet.uuid);
      if (p != null) {
         p.getPersistentData().putBoolean("EF_IsFlying", packet.flying);
      }
   }
}
