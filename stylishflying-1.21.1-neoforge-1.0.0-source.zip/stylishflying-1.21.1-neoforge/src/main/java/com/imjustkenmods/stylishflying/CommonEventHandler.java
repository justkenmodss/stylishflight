package com.imjustkenmods.stylishflying;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.WeakHashMap;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.item.component.CustomData;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.energy.IEnergyStorage;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;
import net.neoforged.neoforge.event.entity.EntityLeaveLevelEvent;
import net.neoforged.neoforge.event.entity.living.LivingDamageEvent;
import net.neoforged.neoforge.event.entity.living.LivingFallEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent.StartTracking;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.items.IItemHandler;
import net.neoforged.neoforge.network.PacketDistributor;

public class CommonEventHandler {
   private static boolean curiosInitialized = false;
   private static Method getCuriosInventoryMethod = null;
   private static Method getEquippedCuriosMethod = null;
   private static final WeakHashMap<Player, CommonEventHandler.CachedItems> EQUIPPED_CACHE = new WeakHashMap<>();
   private static final Map<String, float[]> customSpeedCache = new HashMap<>();
   private static int lastCustomSpeedConfigHash = 0;

   // Curios for 1.21: CuriosApi.getCuriosInventory(entity) -> Optional<ICuriosItemHandler>,
   // then ICuriosItemHandler.getEquippedCurios() -> IItemHandlerModifiable
   private static void initCuriosReflection() {
      if (!curiosInitialized) {
         try {
            Class<?> curiosApi = Class.forName("top.theillusivec4.curios.api.CuriosApi");
            getCuriosInventoryMethod = curiosApi.getMethod("getCuriosInventory", LivingEntity.class);
            Class<?> curiosHandler = Class.forName("top.theillusivec4.curios.api.type.capability.ICuriosItemHandler");
            getEquippedCuriosMethod = curiosHandler.getMethod("getEquippedCurios");
         } catch (Exception ignored) {
            getCuriosInventoryMethod = null;
            getEquippedCuriosMethod = null;
         }

         curiosInitialized = true;
      }
   }

   public static Iterable<ItemStack> getAllEquippedItems(Player player) {
      CommonEventHandler.CachedItems cached = EQUIPPED_CACHE.get(player);
      if (cached != null && cached.tickCount == player.tickCount) {
         return cached.items;
      } else {
         List<ItemStack> items = new ArrayList<>();
         player.getArmorSlots().forEach(items::add);
         if (!ModConfigManager.ENABLE_CURIOS_SUPPORT.get()) {
            EQUIPPED_CACHE.put(player, new CommonEventHandler.CachedItems(player.tickCount, items));
            return items;
         } else {
            initCuriosReflection();
            if (getCuriosInventoryMethod != null && getEquippedCuriosMethod != null) {
               try {
                  Optional<?> optional = (Optional<?>)getCuriosInventoryMethod.invoke(null, player);
                  if (optional.isPresent()) {
                     Object equipped = getEquippedCuriosMethod.invoke(optional.get());
                     if (equipped instanceof IItemHandler handler) {
                        for (int i = 0; i < handler.getSlots(); i++) {
                           items.add(handler.getStackInSlot(i));
                        }
                     }
                  }
               } catch (Exception ignored) {
               }
            }

            EQUIPPED_CACHE.put(player, new CommonEventHandler.CachedItems(player.tickCount, items));
            return items;
         }
      }
   }

   @SubscribeEvent
   public void onEntityLeave(EntityLeaveLevelEvent event) {
      if (event.getEntity() instanceof Player player) {
         FlightState.remove(player.getUUID());
      }
   }

   @SubscribeEvent
   public void onLivingFall(LivingFallEvent event) {
      if (event.getEntity() instanceof Player player && ModConfigManager.ENABLE_NOFALL.get() && hasFlightAccess(player)) {
         event.setCanceled(true);
      }
   }

   @SubscribeEvent
   public void onStartTracking(StartTracking event) {
      if (event.getTarget() instanceof Player target) {
         ServerPlayer tracker = (ServerPlayer)event.getEntity();
         PacketDistributor.sendToPlayer(tracker, new ClientboundSyncFlightPacket(target.getUUID(), target.getAbilities().flying));
         PacketDistributor.sendToPlayer(tracker, new ClientboundSyncBoostPacket(target.getUUID(), target.getPersistentData().getBoolean("EF_IsBoosting")));
      }
   }

   @SubscribeEvent
   public void onPlayerTick(PlayerTickEvent.Post event) {
      if (!event.getEntity().level().isClientSide) {
         Player player = event.getEntity();
         boolean prevFlying = player.getPersistentData().getBoolean("EF_LastFlying");
         if (prevFlying != player.getAbilities().flying) {
            player.getPersistentData().putBoolean("EF_LastFlying", player.getAbilities().flying);
            PacketDistributor.sendToPlayersTrackingEntityAndSelf(player, new ClientboundSyncFlightPacket(player.getUUID(), player.getAbilities().flying));
         }

         double dy = player.getY() - player.yo;
         double prevDy = player.getPersistentData().getDouble("EF_PrevDY");
         player.getPersistentData().putDouble("EF_PrevDY", dy);
         if (isFlyingForAnimation(player)) {
            player.getPersistentData().putBoolean("EF_WasFlyingServer", true);
         }

         if (!player.onGround() && dy < -0.1) {
            int fallTicks = player.getPersistentData().getInt("EF_FallTicks");
            player.getPersistentData().putInt("EF_FallTicks", fallTicks + 1);
         }

         if (player.onGround() && !player.getPersistentData().getBoolean("EF_WasOnGround")) {
            boolean wasFlying = player.getPersistentData().getBoolean("EF_WasFlyingServer");
            int prevFallTicks = player.getPersistentData().getInt("EF_FallTicks");
            if (hasLandingShockwave(player) && prevDy < -0.8 && (wasFlying || prevFallTicks > 12)) {
               double impactStrength = Math.min(Math.abs(prevDy), 4.0);
               PacketDistributor.sendToPlayersTrackingEntityAndSelf(player, new ClientboundLandingVfxPacket(player.getUUID(), impactStrength));
               double cfgDamage = ModConfigManager.LANDING_DAMAGE.get();
               double cfgRadius = ModConfigManager.LANDING_RADIUS.get();
               double cfgKnockback = ModConfigManager.LANDING_KNOCKBACK.get();

               for (LivingEntity e : player.level().getEntitiesOfClass(LivingEntity.class, player.getBoundingBox().inflate(cfgRadius, 1.0, cfgRadius), ex -> ex != player)) {
                  double hdx = e.getX() - player.getX();
                  double hdz = e.getZ() - player.getZ();
                  double horizontalDist = Math.sqrt(hdx * hdx + hdz * hdz);
                  if (horizontalDist <= cfgRadius) {
                     e.hurt(player.damageSources().playerAttack(player), (float)cfgDamage);
                     e.knockback(cfgKnockback * 0.3, player.getX() - e.getX(), player.getZ() - e.getZ());
                  }
               }
            }

            player.getPersistentData().putBoolean("EF_WasFlyingServer", false);
            player.getPersistentData().putInt("EF_FallTicks", 0);
         } else if (player.onGround()) {
            player.getPersistentData().putBoolean("EF_WasFlyingServer", false);
            player.getPersistentData().putInt("EF_FallTicks", 0);
         }

         player.getPersistentData().putBoolean("EF_WasOnGround", player.onGround());
         if (player.tickCount % 4 == 0) {
            boolean dimRestricted = false;
            if (ModConfigManager.ENABLE_DIMENSION_RESTRICTION.get()) {
               String currentDim = player.level().dimension().location().toString();
               boolean inList = (ModConfigManager.DIMENSION_LIST.get()).contains(currentDim);
               dimRestricted = ModConfigManager.DIMENSION_IS_WHITELIST.get() ? !inList : inList;
            }

            boolean itemsGrantFlight = ModConfigManager.ITEMS_GRANT_FLIGHT.get();
            // with items_grant_flight off this stays false, which also takes back flight given by older versions
            boolean shouldGrantFlight = itemsGrantFlight && hasFlightItem(player) && !dimRestricted;
            if (ModConfigManager.ENABLE_KINETIC_DESTRUCTION.get() && player.getPersistentData().getBoolean("EF_IsBoosting")) {
               Vec3 look = player.getLookAngle();
               AABB box = player.getBoundingBox().expandTowards(look.x * 3.0, look.y * 3.0, look.z * 3.0).inflate(0.6);
               BlockPos.betweenClosedStream(box).forEach(pos -> {
                  BlockState bState = player.level().getBlockState(pos);
                  if (!bState.isAir()) {
                     ResourceLocation blockId = BuiltInRegistries.BLOCK.getKey(bState.getBlock());
                     if (blockId != null) {
                        String bName = blockId.toString();

                        for (String entry : ModConfigManager.KINETIC_BLOCKS.get()) {
                           boolean match = false;
                           if (entry.startsWith("#")) {
                              ResourceLocation tagRL = ResourceLocation.tryParse(entry.substring(1));
                              match = tagRL != null && bState.is(BlockTags.create(tagRL));
                           } else {
                              match = entry.equals(bName);
                           }

                           if (match) {
                              player.level().destroyBlock(pos.immutable(), true, player);
                              break;
                           }
                        }
                     }
                  }
               });
            }

            if (player.getPersistentData().contains("EF_GroundedTimer")) {
               int timer = player.getPersistentData().getInt("EF_GroundedTimer");
               if (timer > 0) {
                  player.getPersistentData().putInt("EF_GroundedTimer", timer - 2);
                  shouldGrantFlight = false;
               }
            }

            boolean canAfford = true;
            if (shouldGrantFlight
               && player.getAbilities().flying
               && ModConfigManager.ENABLE_FLIGHT_COST.get()
               && !player.isCreative()
               && !player.isSpectator()) {
               double speed = player.getDeltaMovement().length();
               boolean isBoosting = speed > ModConfigManager.STAGE_1_SPEED.get() * 1.5;
               if ((!ModConfigManager.COST_ONLY_ON_BOOST.get() || isBoosting) && player.tickCount % 20 == 0) {
                  ModConfigManager.CostType costType = ModConfigManager.FLIGHT_COST_TYPE.get();
                  int amount = ModConfigManager.FLIGHT_COST_AMOUNT.get();
                  if (costType == ModConfigManager.CostType.HUNGER) {
                     if (player.getFoodData().getFoodLevel() >= amount) {
                        player.getFoodData().setFoodLevel(player.getFoodData().getFoodLevel() - amount);
                     } else {
                        canAfford = false;
                     }
                  } else if (costType == ModConfigManager.CostType.XP) {
                     if (player.totalExperience >= amount) {
                        player.giveExperiencePoints(-amount);
                     } else {
                        canAfford = false;
                     }
                  } else if (costType == ModConfigManager.CostType.HEALTH) {
                     if (player.getHealth() > (float)amount) {
                        player.setHealth(player.getHealth() - (float)amount);
                     } else {
                        canAfford = false;
                     }
                  } else if (costType == ModConfigManager.CostType.DURABILITY) {
                     boolean damaged = false;

                     for (ItemStack armor : player.getArmorSlots()) {
                        if (!armor.isEmpty() && armor.isDamageableItem()) {
                           armor.hurtAndBreak(amount, player, player.getEquipmentSlotForItem(armor));
                           damaged = true;
                           break;
                        }
                     }

                     if (!damaged) {
                        canAfford = false;
                     }
                  } else if (costType == ModConfigManager.CostType.FE_ENERGY) {
                     boolean paid = false;

                     for (ItemStack armorx : getAllEquippedItems(player)) {
                        if (!armorx.isEmpty()) {
                           IEnergyStorage energy = armorx.getCapability(Capabilities.EnergyStorage.ITEM);
                           if (energy != null && energy.getEnergyStored() >= amount) {
                              energy.extractEnergy(amount, false);
                              paid = true;
                              break;
                           }
                        }
                     }

                     if (!paid) {
                        canAfford = false;
                     }
                  }
               }
            }

            if (!canAfford) {
               shouldGrantFlight = false;
            }

            if (itemsGrantFlight && dimRestricted && hasFlightItem(player) && !player.isCreative() && !player.isSpectator()) {
               shouldGrantFlight = false;
               if (player.getAbilities().mayfly || player.getAbilities().flying) {
                  player.getAbilities().mayfly = false;
                  player.getAbilities().flying = false;
                  player.onUpdateAbilities();
               }

               player.getPersistentData().remove("stylishflying_granted_flight");
            } else if (shouldGrantFlight) {
               if (!player.isCreative() && !player.isSpectator() && !player.getAbilities().mayfly) {
                  player.getAbilities().mayfly = true;
                  player.onUpdateAbilities();
               }

               player.getPersistentData().putBoolean("stylishflying_granted_flight", true);
            } else if (player.getPersistentData().getBoolean("stylishflying_granted_flight")) {
               if (!player.isCreative() && !player.isSpectator()) {
                  player.getAbilities().mayfly = false;
                  player.getAbilities().flying = false;
                  player.onUpdateAbilities();
               }

               player.getPersistentData().remove("stylishflying_granted_flight");
            }
         }
      }
   }

   /**
    * Whether Stylish Flying's flight features apply to this player: creative or spectator, any other source of
    * creative-style flight (mayFly() covers NeoForge's creative flight attribute), or, when items_grant_flight is on,
    * a configured flight item.
    */
   public static boolean hasFlightAccess(Player player) {
      if (player.isCreative() || player.isSpectator() || player.mayFly()) {
         return true;
      } else {
         return ModConfigManager.ITEMS_GRANT_FLIGHT.get() && hasFlightItem(player);
      }
   }

   public static boolean hasFlightItem(Player player) {
      if (getAnimTypeExplicit(player) != null) {
         return true;
      } else {
         List<? extends String> upgrades = ModConfigManager.FLIGHT_UPGRADES.get();

         for (ItemStack armor : getAllEquippedItems(player)) {
            if (!armor.isEmpty()) {
               if (armor.is(ModTags.FLIGHT_UPGRADES)) {
                  return true;
               }

               ResourceLocation id = BuiltInRegistries.ITEM.getKey(armor.getItem());
               String registryName = id != null ? id.toString() : "";
               String nbtString = null;

               for (String upgradeConfig : upgrades) {
                  if (registryName.equals(upgradeConfig)) {
                     return true;
                  }

                  if (upgradeConfig.contains("{")) {
                     if (nbtString == null) {
                        nbtString = armor.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().toString();
                     }

                     if (nbtString.contains(upgradeConfig)) {
                        return true;
                     }
                  }
               }
            }
         }

         return false;
      }
   }

   public static FlightAnimType getAnimTypeExplicit(Player player) {
      for (ItemStack armor : getAllEquippedItems(player)) {
         if (!armor.isEmpty()) {
            if (armor.getItem() != ModItems.HORIZONTAL_ARMS_FORWARD_CHESTPLATE.get() && !armor.is(ModTags.HORIZONTAL_ARMS_FORWARD_ANIM)) {
               if (armor.getItem() != ModItems.VERTICAL_ARMS_DOWN_CHESTPLATE.get() && !armor.is(ModTags.VERTICAL_ARMS_DOWN_ANIM)) {
                  if (armor.getItem() != ModItems.HORIZONTAL_ARMS_BACK_CHESTPLATE.get() && !armor.is(ModTags.HORIZONTAL_ARMS_BACK_ANIM)) {
                     if (armor.getItem() != ModItems.VERTICAL_ARMS_OUT_CHESTPLATE.get() && !armor.is(ModTags.VERTICAL_ARMS_OUT_ANIM)) {
                        if (armor.getItem() != ModItems.VERTICAL_ARMS_FORWARD_CHESTPLATE.get() && !armor.is(ModTags.VERTICAL_ARMS_FORWARD_ANIM)) {
                           if (armor.getItem() != ModItems.HORIZONTAL_ARMS_FORWARD_VARIANT_A_CHESTPLATE.get()
                              && !armor.is(ModTags.HORIZONTAL_ARMS_FORWARD_VARIANT_A_ANIM)) {
                              if (armor.getItem() != ModItems.HORIZONTAL_ARMS_FORWARD_VARIANT_B_CHESTPLATE.get()
                                 && !armor.is(ModTags.HORIZONTAL_ARMS_FORWARD_VARIANT_B_ANIM)) {
                                 if (armor.getItem() != ModItems.VERTICAL_ARMS_DOWN_VARIANT_A_CHESTPLATE.get()
                                    && !armor.is(ModTags.VERTICAL_ARMS_DOWN_VARIANT_A_ANIM)) {
                                    if (armor.getItem() != ModItems.SURFING_POSTURE_CHESTPLATE.get() && !armor.is(ModTags.SURFING_POSTURE_ANIM)) {
                                       ResourceLocation id = BuiltInRegistries.ITEM.getKey(armor.getItem());
                                       if (id != null) {
                                          String name = id.toString();
                                          if ((ModConfigManager.horizontal_arms_forward_ARMORS.get()).contains(name)) {
                                             return FlightAnimType.HORIZONTAL_ARMS_FORWARD;
                                          }

                                          if ((ModConfigManager.vertical_arms_down_ARMORS.get()).contains(name)) {
                                             return FlightAnimType.VERTICAL_ARMS_DOWN;
                                          }

                                          if ((ModConfigManager.horizontal_arms_back_ARMORS.get()).contains(name)) {
                                             return FlightAnimType.HORIZONTAL_ARMS_BACK;
                                          }

                                          if ((ModConfigManager.LEVITATE_ARMORS.get()).contains(name)) {
                                             return FlightAnimType.VERTICAL_ARMS_OUT;
                                          }

                                          if ((ModConfigManager.FORWARD_ARMORS.get()).contains(name)) {
                                             return FlightAnimType.VERTICAL_ARMS_FORWARD;
                                          }

                                          if ((ModConfigManager.HORIZONTAL_ARMS_FORWARD_VARIANT_A_ARMORS.get()).contains(name)) {
                                             return FlightAnimType.HORIZONTAL_ARMS_FORWARD_VARIANT_A;
                                          }

                                          if ((ModConfigManager.HORIZONTAL_ARMS_FORWARD_VARIANT_B_ARMORS.get()).contains(name)) {
                                             return FlightAnimType.HORIZONTAL_ARMS_FORWARD_VARIANT_B;
                                          }

                                          if ((ModConfigManager.VERTICAL_ARMS_DOWN_VARIANT_A_ARMORS.get()).contains(name)) {
                                             return FlightAnimType.VERTICAL_ARMS_DOWN_VARIANT_A;
                                          }

                                          if ((ModConfigManager.SURFING_POSTURE_ARMORS.get()).contains(name)) {
                                             return FlightAnimType.SURFING_POSTURE;
                                          }
                                       }
                                       continue;
                                    }

                                    return FlightAnimType.SURFING_POSTURE;
                                 }

                                 return FlightAnimType.VERTICAL_ARMS_DOWN_VARIANT_A;
                              }

                              return FlightAnimType.HORIZONTAL_ARMS_FORWARD_VARIANT_B;
                           }

                           return FlightAnimType.HORIZONTAL_ARMS_FORWARD_VARIANT_A;
                        }

                        return FlightAnimType.VERTICAL_ARMS_FORWARD;
                     }

                     return FlightAnimType.VERTICAL_ARMS_OUT;
                  }

                  return FlightAnimType.HORIZONTAL_ARMS_BACK;
               }

               return FlightAnimType.VERTICAL_ARMS_DOWN;
            }

            return FlightAnimType.HORIZONTAL_ARMS_FORWARD;
         }
      }

      for (String entry : ModConfigManager.CURIOS_FLIGHT_ITEMS.get()) {
         String[] parts = entry.split("\\s*[|;,]\\s*");
         if (parts.length >= 2) {
            String targetId = parts[0].trim();

            for (ItemStack equipped : getAllEquippedItems(player)) {
               if (!equipped.isEmpty()) {
                  ResourceLocation id = BuiltInRegistries.ITEM.getKey(equipped.getItem());
                  if (id != null && id.toString().equals(targetId)) {
                     try {
                        return FlightAnimType.valueOf(parts[1].trim().toUpperCase());
                     } catch (IllegalArgumentException ignored) {
                     }
                  }
               }
            }
         }
      }

      if (ModConfigManager.ENABLE_POTION_FLIGHT.get()) {
         for (MobEffectInstance instance : player.getActiveEffects()) {
            ResourceLocation effectId = instance.getEffect().unwrapKey().map(key -> key.location()).orElse(null);
            if (effectId != null) {
               String effStr = effectId.toString();

               for (String confStr : ModConfigManager.FLIGHT_POTIONS.get()) {
                  if (effStr.equals(confStr) || effStr.contains(confStr)) {
                     return ModConfigManager.POTION_FLIGHT_ANIMATION.get();
                  }
               }
            }
         }
      }

      return null;
   }

   public static FlightAnimType getAnimType(Player player) {
      FlightAnimType explicit = getAnimTypeExplicit(player);
      if (explicit != null) {
         return explicit;
      } else {
         return ModConfigManager.ENABLE_DEFAULT_FLIGHT.get() ? ModConfigManager.DEFAULT_FLIGHT_ANIMATION.get() : null;
      }
   }

   public static boolean isGroundedImmune(Player player) {
      for (String entry : ModConfigManager.GROUNDED_ARMOR_OVERRIDES.get()) {
         String[] parts = entry.split("\\s*[|;,]\\s*");
         if (parts.length >= 2) {
            for (ItemStack armor : getAllEquippedItems(player)) {
               if (!armor.isEmpty()) {
                  ResourceLocation id = BuiltInRegistries.ITEM.getKey(armor.getItem());
                  if (id != null && id.toString().equals(parts[0].trim())) {
                     return parts[1].trim().equalsIgnoreCase("false");
                  }
               }
            }
         }
      }

      return false;
   }

   public static boolean hasLandingShockwave(Player player) {
      if (!hasFlightAccess(player)) {
         return false;
      } else {
         boolean def = ModConfigManager.ENABLE_LANDING_SHOCKWAVE.get();

         for (String entry : ModConfigManager.LANDING_ARMOR_OVERRIDES.get()) {
            String[] parts = entry.split("\\s*[|;,]\\s*");
            if (parts.length >= 2) {
               for (ItemStack armor : getAllEquippedItems(player)) {
                  if (!armor.isEmpty()) {
                     ResourceLocation id = BuiltInRegistries.ITEM.getKey(armor.getItem());
                     if (id != null && id.toString().equals(parts[0].trim())) {
                        return parts[1].trim().equalsIgnoreCase("true");
                     }
                  }
               }
            }
         }

         return def;
      }
   }

   public static double[] getTakeoffParams(Player player) {
      double defH = ModConfigManager.TAKEOFF_HEIGHT.get();
      double defS = ModConfigManager.TAKEOFF_SPEED.get();

      for (String entry : ModConfigManager.TAKEOFF_ARMOR_OVERRIDES.get()) {
         String[] parts = entry.split("\\s*[|;,]\\s*");
         if (parts.length == 3) {
            for (ItemStack armor : getAllEquippedItems(player)) {
               if (!armor.isEmpty()) {
                  ResourceLocation id = BuiltInRegistries.ITEM.getKey(armor.getItem());
                  if (id != null && id.toString().equals(parts[0].trim())) {
                     try {
                        return new double[]{Double.parseDouble(parts[1].trim()), Double.parseDouble(parts[2].trim())};
                     } catch (Exception ignored) {
                     }
                  }
               }
            }
         }
      }

      return new double[]{defH, defS};
   }

   public static int getMaxHeat(Player player) {
      int def = ModConfigManager.OVERHEAT_MAX_HEAT.get();

      for (String entry : ModConfigManager.OVERHEAT_ARMOR_OVERRIDES.get()) {
         String[] parts = entry.split("\\s*[|;,]\\s*");
         if (parts.length >= 2) {
            for (ItemStack armor : getAllEquippedItems(player)) {
               if (!armor.isEmpty()) {
                  ResourceLocation id = BuiltInRegistries.ITEM.getKey(armor.getItem());
                  if (id != null && id.toString().equals(parts[0].trim())) {
                     try {
                        return Integer.parseInt(parts[1].trim());
                     } catch (Exception ignored) {
                     }
                  }
               }
            }
         }
      }

      return def;
   }

   @SubscribeEvent
   public void onLivingDamage(LivingDamageEvent.Post event) {
      if (ModConfigManager.ENABLE_GROUNDED.get()) {
         if (event.getEntity() instanceof Player player && player.getAbilities().flying && event.getSource().getEntity() != null && !isGroundedImmune(player)) {
            player.getPersistentData().putInt("EF_GroundedTimer", ModConfigManager.GROUNDED_DURATION_TICKS.get());
         }
      }
   }

   public static float[] getSpeeds(Player player) {
      float defaultS1 = (ModConfigManager.STAGE_1_SPEED.get()).floatValue();
      float defaultS2 = (ModConfigManager.STAGE_2_SPEED.get()).floatValue();
      List<? extends String> configList = ModConfigManager.CUSTOM_SPEEDS.get();
      if (configList.hashCode() != lastCustomSpeedConfigHash) {
         customSpeedCache.clear();

         for (String entry : configList) {
            String[] parts = entry.split("\\s*[|;,]\\s*");
            if (parts.length == 3) {
               try {
                  customSpeedCache.put(parts[0].trim(), new float[]{Float.parseFloat(parts[1].trim()), Float.parseFloat(parts[2].trim())});
               } catch (Exception ignored) {
               }
            }
         }

         lastCustomSpeedConfigHash = configList.hashCode();
      }

      if (!customSpeedCache.isEmpty()) {
         for (ItemStack armor : getAllEquippedItems(player)) {
            if (!armor.isEmpty()) {
               ResourceLocation id = BuiltInRegistries.ITEM.getKey(armor.getItem());
               if (id != null) {
                  float[] custom = customSpeedCache.get(id.toString());
                  if (custom != null) {
                     return custom;
                  }
               }
            }
         }
      }

      for (String entryx : ModConfigManager.CURIOS_FLIGHT_ITEMS.get()) {
         String[] parts = entryx.split("\\s*[|;,]\\s*");
         if (parts.length >= 4) {
            String targetId = parts[0].trim();

            for (ItemStack equipped : getAllEquippedItems(player)) {
               if (!equipped.isEmpty()) {
                  ResourceLocation id = BuiltInRegistries.ITEM.getKey(equipped.getItem());
                  if (id != null && id.toString().equals(targetId)) {
                     try {
                        return new float[]{Float.parseFloat(parts[2].trim()), Float.parseFloat(parts[3].trim())};
                     } catch (Exception ignored) {
                     }
                  }
               }
            }
         }
      }

      return new float[]{defaultS1, defaultS2};
   }

   public static boolean isFlyingForAnimation(Player player) {
      if (player.getAbilities().flying) {
         return true;
      } else {
         return player.getPersistentData().getBoolean("EF_IsFlying") ? true : player.isFallFlying();
      }
   }

   private static class CachedItems {
      int tickCount;
      List<ItemStack> items;

      CachedItems(int tickCount, List<ItemStack> items) {
         this.tickCount = tickCount;
         this.items = items;
      }
   }
}
