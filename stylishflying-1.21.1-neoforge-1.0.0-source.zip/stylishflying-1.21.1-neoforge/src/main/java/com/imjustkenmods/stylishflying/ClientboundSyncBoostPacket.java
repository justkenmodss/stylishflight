package com.imjustkenmods.stylishflying;

import io.netty.buffer.ByteBuf;
import java.util.UUID;
import net.minecraft.core.UUIDUtil;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Player;
import net.neoforged.neoforge.network.handling.IPayloadContext;

public record ClientboundSyncBoostPacket(UUID uuid, boolean boosting) implements CustomPacketPayload {
   public static final Type<ClientboundSyncBoostPacket> TYPE = new Type<>(ResourceLocation.fromNamespaceAndPath(StylishFlying.MODID, "sync_boost"));
   public static final StreamCodec<ByteBuf, ClientboundSyncBoostPacket> STREAM_CODEC = StreamCodec.composite(
      UUIDUtil.STREAM_CODEC, ClientboundSyncBoostPacket::uuid,
      ByteBufCodecs.BOOL, ClientboundSyncBoostPacket::boosting,
      ClientboundSyncBoostPacket::new
   );

   @Override
   public Type<ClientboundSyncBoostPacket> type() {
      return TYPE;
   }

   public static void handle(ClientboundSyncBoostPacket packet, IPayloadContext context) {
      Player p = context.player().level().getPlayerByUUID(packet.uuid);
      if (p != null) {
         p.getPersistentData().putBoolean("EF_IsBoostingSync", packet.boosting);
      }
   }
}
