package com.imjustkenmods.stylishflying;

import com.mojang.blaze3d.platform.InputConstants;
import com.mojang.blaze3d.platform.InputConstants.Key;
import com.mojang.blaze3d.platform.InputConstants.Type;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.neoforge.client.event.ComputeFovModifierEvent;
import net.neoforged.neoforge.client.event.MovementInputUpdateEvent;
import net.neoforged.neoforge.client.event.RenderPlayerEvent.Pre;
import net.neoforged.neoforge.client.event.ViewportEvent.ComputeCameraAngles;
import com.imjustkenmods.stylishflying.compat.AnimationCompat;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.network.PacketDistributor;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import org.lwjgl.glfw.GLFW;

@EventBusSubscriber(
   modid = "stylishflying",
   value = {Dist.CLIENT}
)
public class ClientEventHandler {
   private static boolean wasJumpDown = false;

   @SubscribeEvent
   public static void onMovementInput(MovementInputUpdateEvent event) {
      Player player = event.getEntity();
      if (player.getAbilities().flying) {
         FlightState state = FlightState.get(player.getUUID());
         if (state.isBoosting) {
            event.getInput().leftImpulse = 0.0F;
            event.getInput().up = false;
            event.getInput().down = false;
            event.getInput().jumping = false;
            event.getInput().shiftKeyDown = false;
         }
      }
   }

   @SubscribeEvent
   public static void onClientTick(ClientTickEvent.Post event) {
      Minecraft mc = Minecraft.getInstance();
      AnimationCompat.clientTick();
      if (mc.level != null && !mc.isPaused()) {
         for (Player p : mc.level.players()) {
            FlightAnimType animType = CommonEventHandler.getAnimType(p);
            boolean flying = CommonEventHandler.isFlyingForAnimation(p) && animType != null;
            boolean hasElytra = p.getItemBySlot(EquipmentSlot.CHEST).is(Items.ELYTRA);
            boolean boosting = false;
            FlightState state = FlightState.get(p.getUUID());
            if (p != mc.player) {
               boosting = p.getPersistentData().getBoolean("EF_IsBoostingSync");
            } else {
               boolean isJumpDown = mc.options.keyJump.isDown() && mc.screen == null;
               boolean jumpPressed = isJumpDown && !wasJumpDown;
               wasJumpDown = isJumpDown;
               if (jumpPressed && !flying && state.freefallTimer > 0.0F && p.getAbilities().mayfly) {
                  p.getAbilities().flying = true;
                  p.onUpdateAbilities();
                  flying = true;
                  boosting = true;
               }

               if (flying && p.zza > 0.0F && !hasElytra && !p.isFallFlying() && (p.isCreative() || p.getAbilities().mayfly)) {
                  Key key = ModKeybinds.BOOST_KEY.getKey();
                  long window = mc.getWindow().getWindow();
                  if (mc.screen == null) {
                     if (key.getType() == Type.MOUSE) {
                        boosting = GLFW.glfwGetMouseButton(window, key.getValue()) == 1;
                     } else if (key.getType() == Type.KEYSYM) {
                        boosting = InputConstants.isKeyDown(window, key.getValue());
                     }
                  }
               }
            }

            if (p == mc.player) {
               boolean prevBoost = p.getPersistentData().getBoolean("EF_IsBoostingClient");
               if (prevBoost != boosting) {
                  p.getPersistentData().putBoolean("EF_IsBoostingClient", boosting);
                  PacketDistributor.sendToServer(new ServerboundBoostPacket(boosting));
               }
            }

            boolean hasFlightAbility = CommonEventHandler.hasFlightAccess(p);
            if (ModConfigManager.ENABLE_OVERHEAT.get() && hasFlightAbility) {
               int maxHeat = CommonEventHandler.getMaxHeat(p);
               if (boosting && !state.overheated) {
                  state.heat += 2.0F;
                  if (state.heat >= (float)maxHeat) {
                     state.overheated = true;
                     boosting = false;
                  }
               } else {
                  state.heat--;
                  if (state.heat <= 0.0F) {
                     state.heat = 0.0F;
                     state.overheated = false;
                  }
               }

               if (state.overheated) {
                  boosting = false;
               }
            } else {
               state.heat = 0.0F;
               state.overheated = false;
            }

            if (p == mc.player) {
               if (ModConfigManager.ENABLE_TAKEOFF.get() && p.onGround() && !flying && hasFlightAbility) {
                  boolean takeoffKeyDown = false;
                  Key tk = ModKeybinds.TAKEOFF_KEY.getKey();
                  long window = mc.getWindow().getWindow();
                  if (mc.screen == null) {
                     if (tk.getType() == Type.MOUSE) {
                        takeoffKeyDown = GLFW.glfwGetMouseButton(window, tk.getValue()) == 1;
                     } else if (tk.getType() == Type.KEYSYM) {
                        takeoffKeyDown = InputConstants.isKeyDown(window, tk.getValue());
                     }
                  }

                  if (takeoffKeyDown) {
                     float prevCharge = state.takeoffCharge;
                     state.takeoffCharge = Math.min(1.0F, state.takeoffCharge + 0.03F);
                     if (ModConfigManager.TAKEOFF_ENABLE_VFX.get()) {
                        double px = p.getX();
                        double py = p.getY() + 0.1;
                        double pz = p.getZ();
                        long time = System.currentTimeMillis();
                        int particleCount = 1 + (int)(state.takeoffCharge * 4.0F);
                        double radius = 1.2 - (double)state.takeoffCharge * 0.5;

                        for (int i = 0; i < particleCount; i++) {
                           double angle = Math.toRadians((double)time / 4.0 + (double)i * (360.0 / (double)particleCount));
                           double ox = Math.cos(angle) * radius;
                           double oz = Math.sin(angle) * radius;
                           double oy = (double)state.takeoffCharge * 1.8 * (double)((float)i / (float)particleCount);
                           p.level().addParticle(ParticleTypes.END_ROD, px + ox, py + oy, pz + oz, 0.0, 0.02, 0.0);
                        }

                        if (state.takeoffCharge > 0.3F) {
                           for (int i = 0; i < 2; i++) {
                              double a = p.getRandom().nextDouble() * Math.PI * 2.0;
                              double r = p.getRandom().nextDouble() * 0.6;
                              p.level()
                                 .addParticle(
                                    ParticleTypes.SOUL_FIRE_FLAME,
                                    px + Math.cos(a) * r,
                                    py,
                                    pz + Math.sin(a) * r,
                                    0.0,
                                    0.04 + (double)state.takeoffCharge * 0.03,
                                    0.0
                                 );
                           }
                        }

                        if (state.takeoffCharge >= 1.0F) {
                           for (int i = 0; i < 3; i++) {
                              p.level()
                                 .addParticle(
                                    ParticleTypes.FIREWORK,
                                    px + (p.getRandom().nextDouble() - 0.5) * 0.3,
                                    py + p.getRandom().nextDouble() * 2.5,
                                    pz + (p.getRandom().nextDouble() - 0.5) * 0.3,
                                    0.0,
                                    0.05,
                                    0.0
                                 );
                           }
                        }
                     }
                  } else if (state.takeoffCharge > 0.3F) {
                     double[] params = CommonEventHandler.getTakeoffParams(p);
                     double px = p.getX();
                     double py = p.getY();
                     double pz = p.getZ();
                     if (ModConfigManager.TAKEOFF_ENABLE_VFX.get()) {
                        for (int i = 0; i < 24; i++) {
                           double angle = Math.toRadians((double)i * 15.0);
                           double speed = 0.3 + (double)state.takeoffCharge * 0.4;
                           double vx = Math.cos(angle) * speed;
                           double vz = Math.sin(angle) * speed;
                           p.level().addParticle(ParticleTypes.CLOUD, px, py + 0.5, pz, vx, 0.05, vz);
                           p.level().addParticle(ParticleTypes.END_ROD, px, py + 0.2, pz, vx * 0.5, 0.1, vz * 0.5);
                        }

                        for (int i = 0; i < 15; i++) {
                           double oy = (double)i * 0.3;
                           p.level()
                              .addParticle(
                                 ParticleTypes.SOUL_FIRE_FLAME,
                                 px + (p.getRandom().nextDouble() - 0.5) * 0.4,
                                 py + oy,
                                 pz + (p.getRandom().nextDouble() - 0.5) * 0.4,
                                 0.0,
                                 -0.05,
                                 0.0
                              );
                        }

                        for (int i = 0; i < 8; i++) {
                           double a = p.getRandom().nextDouble() * Math.PI * 2.0;
                           double r = 0.5 + p.getRandom().nextDouble() * 1.0;
                           p.level()
                              .addParticle(
                                 ParticleTypes.CAMPFIRE_COSY_SMOKE, px + Math.cos(a) * r, py + 0.1, pz + Math.sin(a) * r, Math.cos(a) * 0.05, 0.08, Math.sin(a) * 0.05
                              );
                        }
                     }

                     if (ModConfigManager.TAKEOFF_ENABLE_SOUND.get()) {
                        p.level().playLocalSound(px, py, pz, SoundEvents.FIREWORK_ROCKET_LAUNCH, SoundSource.PLAYERS, 1.5F, 0.7F + state.takeoffCharge * 0.5F, false);
                     }

                     p.setDeltaMovement(0.0, params[1], 0.0);
                     p.hasImpulse = true;
                     p.setOnGround(false);
                     if (p.getAbilities().mayfly) {
                        p.getAbilities().flying = true;
                     }

                     state.takeoffCharge = 0.0F;
                  } else {
                     state.takeoffCharge = 0.0F;
                  }
               } else {
                  state.takeoffCharge = 0.0F;
               }

               if (flying && hasFlightAbility) {
                  float boostFactor = FlightState.curve(state.boostTimer);
                  float[] speeds = CommonEventHandler.getSpeeds(p);
                  float stage1 = speeds[0];
                  float stage2 = speeds[1];
                  float targetSpeed = Mth.lerp(boostFactor, stage1, stage2);
                  if (boosting) {
                     p.getAbilities().setFlyingSpeed(0.0F);
                     Vec3 look = p.getLookAngle();
                     double terminalVelocity = (double)targetSpeed * 10.0;
                     Vec3 currentMot = p.getDeltaMovement();
                     Vec3 targetMot = look.scale(terminalVelocity);
                     p.setDeltaMovement(currentMot.lerp(targetMot, 0.2));
                  } else {
                     p.getAbilities().setFlyingSpeed(stage1);
                  }
               } else if (!p.getAbilities().flying && p.getAbilities().getFlyingSpeed() != 0.05F) {
                  p.getAbilities().setFlyingSpeed(0.05F);
               }
            }

            state.tick(flying, boosting, p);
         }

         Player player = mc.player;
         if (player != null) {
            FlightState statex = FlightState.get(player.getUUID());
            CameraRollManager.update(player, statex);
         }
      }
   }

   @SubscribeEvent
   public static void onComputeCameraAngles(ComputeCameraAngles event) {
      Player player = Minecraft.getInstance().player;
      if (player != null) {
         FlightAnimType animType = CommonEventHandler.getAnimType(player);
         if (animType != null && player.getAbilities().flying) {
            float partialTick = (float)event.getPartialTick();
            FlightState state = FlightState.get(player.getUUID());
            float roll = CameraRollManager.getInterpolatedRoll(partialTick);
            if (roll != 0.0F) {
               event.setRoll(event.getRoll() + roll);
            }

            float boostFactor = FlightState.curve(Mth.lerp(partialTick, state.prevBoostTimer, state.boostTimer));
            if (boostFactor > 0.0F) {
               float shakeIntensity = boostFactor * 0.15F;
               float shakeX = (player.getRandom().nextFloat() - 0.5F) * shakeIntensity;
               float shakeY = (player.getRandom().nextFloat() - 0.5F) * shakeIntensity;
               event.setPitch(event.getPitch() + shakeX);
               event.setYaw(event.getYaw() + shakeY);
            }
         }
      }
   }

   @SubscribeEvent
   public static void onComputeFovModifier(ComputeFovModifierEvent event) {
      Player player = event.getPlayer();
      if (player != null) {
         FlightAnimType animType = CommonEventHandler.getAnimType(player);
         if (animType != null && player.getAbilities().flying) {
            event.setNewFovModifier(1.0F);
         }
      }
   }

   public static void drawHud(GuiGraphics gui, int screenW, int screenH) {
      Minecraft mc = Minecraft.getInstance();
      if (mc.player != null) {
         FlightState state = FlightState.get(mc.player.getUUID());
         if (ModClientConfig.SHOW_TAKEOFF_BAR.get() && ModConfigManager.ENABLE_TAKEOFF.get() && state.takeoffCharge > 0.0F) {
            float fill = state.takeoffCharge;
            int barW = ModClientConfig.TAKEOFF_BAR_WIDTH.get();
            int barH = ModClientConfig.TAKEOFF_BAR_HEIGHT.get();
            HudAnchor anchor = ModClientConfig.TAKEOFF_BAR_ANCHOR.get();
            int bx;
            int by;
            if (anchor == HudAnchor.HOTBAR) {
               // original spot, keeping the bottom edge in place if the height changes
               bx = screenW / 2 - barW / 2;
               by = screenH - 59 - barH;
            } else {
               bx = anchor.frameX(screenW, barW + 2) + 1;
               by = anchor.frameY(screenH, barH + 2) + 1;
            }

            bx += ModClientConfig.TAKEOFF_BAR_X.get();
            by += ModClientConfig.TAKEOFF_BAR_Y.get();
            boolean flash = fill >= 1.0F && System.currentTimeMillis() / 150L % 2L == 0L;
            drawBar(gui, TAKEOFF_BACKGROUND, flash ? TAKEOFF_FILL_READY : TAKEOFF_FILL, bx, by, barW, barH, fill);
         }

         if (ModClientConfig.SHOW_OVERHEAT_BAR.get() && ModConfigManager.ENABLE_OVERHEAT.get()) {
            boolean show = state.heat > 0.0F || ModClientConfig.OVERHEAT_BAR_ALWAYS_VISIBLE.get() && mc.player.getAbilities().flying;
            if (show) {
               int maxHeat = CommonEventHandler.getMaxHeat(mc.player);
               float fill = maxHeat > 0 ? Mth.clamp(state.heat / (float)maxHeat, 0.0F, 1.0F) : 0.0F;
               int barW = ModClientConfig.OVERHEAT_BAR_WIDTH.get();
               int barH = ModClientConfig.OVERHEAT_BAR_HEIGHT.get();
               HudAnchor anchor = ModClientConfig.OVERHEAT_BAR_ANCHOR.get();
               int bx;
               int by;
               if (anchor == HudAnchor.HOTBAR) {
                  bx = screenW / 2 + 10;
                  by = screenH - 43 - barH;
               } else {
                  bx = anchor.frameX(screenW, barW + 2) + 1;
                  by = anchor.frameY(screenH, barH + 2) + 1;
               }

               bx += ModClientConfig.OVERHEAT_BAR_X.get();
               by += ModClientConfig.OVERHEAT_BAR_Y.get();
               ResourceLocation fillSprite;
               if (state.overheated && System.currentTimeMillis() / 200L % 2L == 0L) {
                  fillSprite = OVERHEAT_FILL_OVERHEATED;
               } else if (fill < 0.5F) {
                  fillSprite = OVERHEAT_FILL_LOW;
               } else if (fill < 0.8F) {
                  fillSprite = OVERHEAT_FILL_MEDIUM;
               } else {
                  fillSprite = OVERHEAT_FILL_HIGH;
               }

               drawBar(gui, OVERHEAT_BACKGROUND, fillSprite, bx, by, barW, barH, fill);
            }
         }
      }
   }

   // GUI sprites, so resource packs can restyle the bars (assets/stylishflying/textures/gui/sprites/hud/)
   private static final ResourceLocation TAKEOFF_BACKGROUND = hudSprite("takeoff_background");
   private static final ResourceLocation TAKEOFF_FILL = hudSprite("takeoff_fill");
   private static final ResourceLocation TAKEOFF_FILL_READY = hudSprite("takeoff_fill_ready");
   private static final ResourceLocation OVERHEAT_BACKGROUND = hudSprite("overheat_background");
   private static final ResourceLocation OVERHEAT_FILL_LOW = hudSprite("overheat_fill_low");
   private static final ResourceLocation OVERHEAT_FILL_MEDIUM = hudSprite("overheat_fill_medium");
   private static final ResourceLocation OVERHEAT_FILL_HIGH = hudSprite("overheat_fill_high");
   private static final ResourceLocation OVERHEAT_FILL_OVERHEATED = hudSprite("overheat_fill_overheated");

   private static ResourceLocation hudSprite(String name) {
      return ResourceLocation.fromNamespaceAndPath("stylishflying", "hud/" + name);
   }

   /**
    * Draws the background one pixel larger than the fill area on every side, then the fill sprite at full size,
    * cut off at the current fill level so its texture is revealed rather than squashed.
    */
   private static void drawBar(GuiGraphics gui, ResourceLocation background, ResourceLocation fillSprite, int bx, int by, int barW, int barH, float fill) {
      gui.blitSprite(background, bx - 1, by - 1, barW + 2, barH + 2);
      if (fill > 0.0F) {
         int fw = Math.max(1, (int)((float)barW * fill));
         gui.enableScissor(bx, by, bx + fw, by + barH);
         gui.blitSprite(fillSprite, bx, by, barW, barH);
         gui.disableScissor();
      }
   }

   @SubscribeEvent
   public static void onRenderPlayerPre(Pre event) {
      AbstractClientPlayer player = (AbstractClientPlayer)event.getEntity();
      FlightAnimType animType = CommonEventHandler.getAnimType(player);
      if (animType != null) {
         if (player.getAbilities().flying) {
            player.walkAnimation.setSpeed(0.0F);
         }
      }
   }
}
