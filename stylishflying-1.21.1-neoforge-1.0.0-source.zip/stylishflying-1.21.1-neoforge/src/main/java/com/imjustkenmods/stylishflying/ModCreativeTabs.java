package com.imjustkenmods.stylishflying;

import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModCreativeTabs {
   public static final DeferredRegister<CreativeModeTab> CREATIVE_MODE_TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, StylishFlying.MODID);
   public static final DeferredHolder<CreativeModeTab, CreativeModeTab> ANIMATION_FLY_TAB = CREATIVE_MODE_TABS.register(
      "animation_fly_tab",
      () -> CreativeModeTab.builder()
            .icon(() -> ModItems.HORIZONTAL_ARMS_FORWARD_CHESTPLATE.get().getDefaultInstance())
            .title(Component.translatable("creativetab.animation_fly_tab"))
            .displayItems((parameters, output) -> {
               output.accept(ModItems.HORIZONTAL_ARMS_FORWARD_CHESTPLATE.get());
               output.accept(ModItems.VERTICAL_ARMS_DOWN_CHESTPLATE.get());
               output.accept(ModItems.HORIZONTAL_ARMS_BACK_CHESTPLATE.get());
               output.accept(ModItems.VERTICAL_ARMS_OUT_CHESTPLATE.get());
               output.accept(ModItems.VERTICAL_ARMS_FORWARD_CHESTPLATE.get());
               output.accept(ModItems.HORIZONTAL_ARMS_FORWARD_VARIANT_A_CHESTPLATE.get());
               output.accept(ModItems.HORIZONTAL_ARMS_FORWARD_VARIANT_B_CHESTPLATE.get());
               output.accept(ModItems.VERTICAL_ARMS_DOWN_VARIANT_A_CHESTPLATE.get());
               output.accept(ModItems.SURFING_POSTURE_CHESTPLATE.get());
            })
            .build()
   );
}
