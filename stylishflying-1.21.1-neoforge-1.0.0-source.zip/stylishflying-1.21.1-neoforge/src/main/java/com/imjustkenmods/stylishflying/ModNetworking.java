package com.imjustkenmods.stylishflying;

import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;

public class ModNetworking {
   private static final String PROTOCOL_VERSION = "1";

   public static void register(RegisterPayloadHandlersEvent event) {
      PayloadRegistrar registrar = event.registrar(PROTOCOL_VERSION);
      registrar.playToServer(ServerboundBoostPacket.TYPE, ServerboundBoostPacket.STREAM_CODEC, ServerboundBoostPacket::handle);
      registrar.playToClient(ClientboundSyncFlightPacket.TYPE, ClientboundSyncFlightPacket.STREAM_CODEC, ClientboundSyncFlightPacket::handle);
      registrar.playToClient(ClientboundSyncBoostPacket.TYPE, ClientboundSyncBoostPacket.STREAM_CODEC, ClientboundSyncBoostPacket::handle);
      registrar.playToClient(ClientboundLandingVfxPacket.TYPE, ClientboundLandingVfxPacket.STREAM_CODEC, ClientboundLandingVfxPacket::handle);
   }
}
