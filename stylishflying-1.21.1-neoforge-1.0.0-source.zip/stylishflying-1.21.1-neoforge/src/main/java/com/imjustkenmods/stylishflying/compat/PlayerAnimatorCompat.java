package com.imjustkenmods.stylishflying.compat;

import dev.kosmx.playerAnim.api.TransformType;
import dev.kosmx.playerAnim.core.util.Vec3f;
import dev.kosmx.playerAnim.impl.IAnimatedPlayer;
import dev.kosmx.playerAnim.impl.animation.AnimationApplier;
import net.minecraft.client.player.AbstractClientPlayer;

/** Only loaded when playerAnimator is installed. */
final class PlayerAnimatorCompat {
   static final int FULL_BODY = 1;
   static final int UPPER_BODY = 2;
   private static final String[] FULL_BODY_PARTS = new String[]{"body", "leftLeg", "rightLeg"};
   private static final String[] UPPER_BODY_PARTS = new String[]{"torso", "head", "rightArm", "leftArm"};
   // a value no animation produces, so any change to it means the part is animated
   private static final float MARK = 1000.0F;

   private PlayerAnimatorCompat() {
   }

   static int drivenParts(AbstractClientPlayer player) {
      if (player instanceof IAnimatedPlayer animated) {
         AnimationApplier animation = animated.playerAnimator_getAnimation();
         if (animation != null && animation.isActive()) {
            int result = 0;
            if (anyDriven(animation, FULL_BODY_PARTS)) {
               result |= FULL_BODY;
            }

            if (anyDriven(animation, UPPER_BODY_PARTS)) {
               result |= UPPER_BODY;
            }

            return result;
         } else {
            return 0;
         }
      } else {
         return 0;
      }
   }

   private static boolean anyDriven(AnimationApplier animation, String[] parts) {
      for (String part : parts) {
         if (changed(animation.get3DTransform(part, TransformType.ROTATION, new Vec3f(MARK, MARK, MARK)))
            || changed(animation.get3DTransform(part, TransformType.POSITION, new Vec3f(MARK, MARK, MARK)))) {
            return true;
         }
      }

      return false;
   }

   private static boolean changed(Vec3f value) {
      return value != null && (value.getX() != MARK || value.getY() != MARK || value.getZ() != MARK);
   }
}
