package com.imjustkenmods.stylishflying;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.ItemTags;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.Item;

public class ModTags {
   public static final TagKey<Item> HORIZONTAL_ARMS_FORWARD_ANIM = ItemTags.create(ResourceLocation.fromNamespaceAndPath(StylishFlying.MODID, "horizontal_arms_forward_animations"));
   public static final TagKey<Item> VERTICAL_ARMS_DOWN_ANIM = ItemTags.create(ResourceLocation.fromNamespaceAndPath(StylishFlying.MODID, "vertical_arms_down_animations"));
   public static final TagKey<Item> HORIZONTAL_ARMS_BACK_ANIM = ItemTags.create(ResourceLocation.fromNamespaceAndPath(StylishFlying.MODID, "horizontal_arms_back_animations"));
   public static final TagKey<Item> VERTICAL_ARMS_OUT_ANIM = ItemTags.create(ResourceLocation.fromNamespaceAndPath(StylishFlying.MODID, "vertical_arms_out_animations"));
   public static final TagKey<Item> VERTICAL_ARMS_FORWARD_ANIM = ItemTags.create(ResourceLocation.fromNamespaceAndPath(StylishFlying.MODID, "vertical_arms_forward_animations"));
   public static final TagKey<Item> HORIZONTAL_ARMS_FORWARD_VARIANT_A_ANIM = ItemTags.create(
      ResourceLocation.fromNamespaceAndPath(StylishFlying.MODID, "horizontal_arms_forward_variant_a_animations")
   );
   public static final TagKey<Item> HORIZONTAL_ARMS_FORWARD_VARIANT_B_ANIM = ItemTags.create(
      ResourceLocation.fromNamespaceAndPath(StylishFlying.MODID, "horizontal_arms_forward_variant_b_animations")
   );
   public static final TagKey<Item> VERTICAL_ARMS_DOWN_VARIANT_A_ANIM = ItemTags.create(
      ResourceLocation.fromNamespaceAndPath(StylishFlying.MODID, "vertical_arms_down_variant_a_animations")
   );
   public static final TagKey<Item> SURFING_POSTURE_ANIM = ItemTags.create(ResourceLocation.fromNamespaceAndPath(StylishFlying.MODID, "surfing_posture_animations"));
   public static final TagKey<Item> FLIGHT_UPGRADES = ItemTags.create(ResourceLocation.fromNamespaceAndPath(StylishFlying.MODID, "flight_upgrades"));
}
