package com.imjustkenmods.stylishflying.mixin;

import com.imjustkenmods.stylishflying.ModConfigManager;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin({Player.class})
public abstract class MixinPlayer {
   // NeoForge 1.21.1 checks mayFly() here (the abilities flag or the creative flight attribute)
   // instead of reading Abilities.mayfly directly
   @Redirect(
      method = {"causeFallDamage"},
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/world/entity/player/Player;mayFly()Z"
      )
   )
   private boolean redirectMayflyFallDamage(Player player) {
      return !ModConfigManager.ENABLE_NOFALL.get() && !player.isCreative() && !player.isSpectator() && !player.getAbilities().flying ? false : player.mayFly();
   }
}
