package com.imjustkenmods.stylishflying;

import net.minecraft.resources.ResourceLocation;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RegisterGuiLayersEvent;

@EventBusSubscriber(modid = StylishFlying.MODID, bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientModEvents {
   @SubscribeEvent
   public static void registerGuiLayers(RegisterGuiLayersEvent event) {
      event.registerAboveAll(
         ResourceLocation.fromNamespaceAndPath(StylishFlying.MODID, "stylishflying_hud"),
         (guiGraphics, deltaTracker) -> ClientEventHandler.drawHud(guiGraphics, guiGraphics.guiWidth(), guiGraphics.guiHeight())
      );
   }
}
