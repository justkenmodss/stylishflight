package com.imjustkenmods.stylishflying;

import net.neoforged.neoforge.common.ModConfigSpec;

public class ModClientConfig {
   public static final ModConfigSpec.Builder BUILDER = new ModConfigSpec.Builder();
   public static final ModConfigSpec.IntValue TAKEOFF_BAR_X;
   public static final ModConfigSpec.IntValue TAKEOFF_BAR_Y;
   public static final ModConfigSpec.IntValue OVERHEAT_BAR_X;
   public static final ModConfigSpec.IntValue OVERHEAT_BAR_Y;
   public static final ModConfigSpec.BooleanValue SHOW_TAKEOFF_BAR;
   public static final ModConfigSpec.EnumValue<HudAnchor> TAKEOFF_BAR_ANCHOR;
   public static final ModConfigSpec.IntValue TAKEOFF_BAR_WIDTH;
   public static final ModConfigSpec.IntValue TAKEOFF_BAR_HEIGHT;
   public static final ModConfigSpec.BooleanValue SHOW_OVERHEAT_BAR;
   public static final ModConfigSpec.EnumValue<HudAnchor> OVERHEAT_BAR_ANCHOR;
   public static final ModConfigSpec.IntValue OVERHEAT_BAR_WIDTH;
   public static final ModConfigSpec.IntValue OVERHEAT_BAR_HEIGHT;
   public static final ModConfigSpec.BooleanValue OVERHEAT_BAR_ALWAYS_VISIBLE;
   public static final ModConfigSpec.BooleanValue YIELD_TO_PLAYER_ANIMATOR;
   public static final ModConfigSpec.BooleanValue YIELD_TO_ARM_ANIMATIONS;
   public static final ModConfigSpec SPEC;

   static {
      BUILDER.comment(
            new String[]{
               "Placement of the HUD bars. Each bar is first put at its anchor, then moved by its x/y offset",
               "(positive x is right, positive y is down). HOTBAR is the original spot; the other anchors",
               "line the matching edge of the bar up with that edge of the screen.",
               "The bar textures can be replaced with a resource pack, see the README.",
               "Turning the overheat mechanic itself on or off is done with 'enable_overheat' in the server config."
            }
         )
         .push("UI Positions");
      SHOW_TAKEOFF_BAR = BUILDER.comment("Show the Sonic Takeoff charge bar.").define("show_takeoff_bar", true);
      TAKEOFF_BAR_ANCHOR = BUILDER.comment("Where the Sonic Takeoff bar is anchored. HOTBAR is above the hotbar.")
         .defineEnum("takeoff_bar_anchor", HudAnchor.HOTBAR);
      TAKEOFF_BAR_X = BUILDER.comment("X offset for the Sonic Takeoff bar.").defineInRange("takeoff_bar_x", 0, -10000, 10000);
      TAKEOFF_BAR_Y = BUILDER.comment("Y offset for the Sonic Takeoff bar.").defineInRange("takeoff_bar_y", 0, -10000, 10000);
      TAKEOFF_BAR_WIDTH = BUILDER.comment("Width of the Sonic Takeoff bar's fill area, in GUI pixels.")
         .defineInRange("takeoff_bar_width", 80, 4, 1000);
      TAKEOFF_BAR_HEIGHT = BUILDER.comment("Height of the Sonic Takeoff bar's fill area, in GUI pixels.")
         .defineInRange("takeoff_bar_height", 5, 1, 200);
      SHOW_OVERHEAT_BAR = BUILDER.comment("Show the Overheat (flight stamina) bar.").define("show_overheat_bar", true);
      OVERHEAT_BAR_ANCHOR = BUILDER.comment("Where the Overheat bar is anchored. HOTBAR is above the food bar.")
         .defineEnum("overheat_bar_anchor", HudAnchor.HOTBAR);
      OVERHEAT_BAR_X = BUILDER.comment("X offset for the Overheat bar.").defineInRange("overheat_bar_x", 0, -10000, 10000);
      OVERHEAT_BAR_Y = BUILDER.comment("Y offset for the Overheat bar.").defineInRange("overheat_bar_y", 0, -10000, 10000);
      OVERHEAT_BAR_WIDTH = BUILDER.comment("Width of the Overheat bar's fill area, in GUI pixels.")
         .defineInRange("overheat_bar_width", 60, 4, 1000);
      OVERHEAT_BAR_HEIGHT = BUILDER.comment("Height of the Overheat bar's fill area, in GUI pixels.")
         .defineInRange("overheat_bar_height", 5, 1, 200);
      OVERHEAT_BAR_ALWAYS_VISIBLE = BUILDER.comment("Keep the Overheat bar on screen while flying even when it is empty.")
         .define("overheat_bar_always_visible", false);
      BUILDER.pop();

      BUILDER.push("Animation Compatibility");
      YIELD_TO_PLAYER_ANIMATOR = BUILDER.comment(
            new String[]{
               "Fade the flight pose out while another mod plays a full-body animation through playerAnimator",
               "(Emotecraft emotes, Combat Roll, full-body attacks or spells), and back in when it ends."
            }
         )
         .define("yield_to_player_animator", true);
      YIELD_TO_ARM_ANIMATIONS = BUILDER.comment(
            new String[]{
               "Also fade the flight pose out for playerAnimator animations that only move the arms or head,",
               "like Iron's Spells casting or Better Combat swings. When off, those arms play on top of the flight pose."
            }
         )
         .define("yield_to_arm_animations", false);
      BUILDER.pop();
      SPEC = BUILDER.build();
   }
}
