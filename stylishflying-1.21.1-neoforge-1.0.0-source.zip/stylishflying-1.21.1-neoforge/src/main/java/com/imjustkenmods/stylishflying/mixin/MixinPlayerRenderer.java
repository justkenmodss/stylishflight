package com.imjustkenmods.stylishflying.mixin;

import com.imjustkenmods.stylishflying.CommonEventHandler;
import com.imjustkenmods.stylishflying.FlightAnimType;
import com.imjustkenmods.stylishflying.FlightAnimator;
import com.imjustkenmods.stylishflying.FlightState;
import com.imjustkenmods.stylishflying.PoseBlender;
import com.imjustkenmods.stylishflying.compat.AnimationCompat;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraft.util.Mth;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({PlayerRenderer.class})
public class MixinPlayerRenderer {
   // how many ticks it takes to fade out for, or back in after, another mod's animation
   @Unique
   private static final float stylishflying$YIELD_IN_TICKS = 4.0F;
   @Unique
   private static final float stylishflying$YIELD_OUT_TICKS = 6.0F;
   // crossfade length when the flight style changes (different armor put on or taken off)
   @Unique
   private static final int stylishflying$STYLE_CHANGE_TICKS = 6;

   // Runs before the model is posed each frame, so it also decides the blend values the model uses.
   @Inject(
      method = {"setupRotations(Lnet/minecraft/client/player/AbstractClientPlayer;Lcom/mojang/blaze3d/vertex/PoseStack;FFFF)V"},
      at = {@At("TAIL")}
   )
   private void stylishflying$onSetupRotations(
      AbstractClientPlayer player, PoseStack poseStack, float bob, float yBodyRot, float partialTick, float scale, CallbackInfo ci
   ) {
      FlightState state = FlightState.get(player.getUUID());
      FlightAnimType animType = CommonEventHandler.getAnimType(player);
      if (animType != state.lastAnimType) {
         state.fadeRequest = Math.max(state.fadeRequest, stylishflying$STYLE_CHANGE_TICKS);
         state.lastAnimType = animType;
      }

      state.startRequestedFade(bob);
      boolean active = animType != null && state.isPoseActive(player);
      boolean yieldWanted = active && AnimationCompat.shouldYield(player);
      float elapsed = state.yieldTime < 0.0F ? 0.0F : Mth.clamp(bob - state.yieldTime, 0.0F, 1.0F);
      state.yieldTime = bob;
      if (yieldWanted) {
         state.yieldAmount = Math.min(1.0F, state.yieldAmount + elapsed / stylishflying$YIELD_IN_TICKS);
      } else {
         state.yieldAmount = Math.max(0.0F, state.yieldAmount - elapsed / stylishflying$YIELD_OUT_TICKS);
      }

      state.renderWeight = 1.0F - FlightState.curve(state.yieldAmount);
      Matrix4f body = new Matrix4f();
      if (active && state.renderWeight > 0.0F) {
         PoseStack local = new PoseStack();
         FlightAnimator.applyBodyTransform(player, state, animType, partialTick, local);
         body.set(local.last().pose());
         if (state.renderWeight < 1.0F) {
            body = PoseBlender.lerp(new Matrix4f(), body, state.renderWeight);
         }
      }

      float fade = state.fadeProgress(bob);
      if (fade >= 0.0F) {
         body = PoseBlender.lerp(state.fadeFromBody, body, fade);
      }

      state.lastBody.set(body);
      poseStack.mulPose(body);
   }
}
