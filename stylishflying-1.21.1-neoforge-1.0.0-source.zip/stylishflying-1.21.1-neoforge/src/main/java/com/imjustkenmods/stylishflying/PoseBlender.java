package com.imjustkenmods.stylishflying;

import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.HumanoidArm;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;

/**
 * Helpers for blending the flight pose with whatever the model held before it (vanilla, other mods),
 * and for crossfading between two poses so nothing pops.
 */
public final class PoseBlender {
   private static final int VALUES_PER_PART = 6;
   private static final int PARTS = 6;
   public static final int SIZE = VALUES_PER_PART * PARTS;

   private PoseBlender() {
   }

   private static ModelPart[] parts(HumanoidModel<?> model) {
      return new ModelPart[]{model.head, model.body, model.rightArm, model.leftArm, model.rightLeg, model.leftLeg};
   }

   public static float[] capture(HumanoidModel<?> model) {
      float[] out = new float[SIZE];
      int i = 0;

      for (ModelPart p : parts(model)) {
         out[i++] = p.x;
         out[i++] = p.y;
         out[i++] = p.z;
         out[i++] = p.xRot;
         out[i++] = p.yRot;
         out[i++] = p.zRot;
      }

      return out;
   }

   public static void write(HumanoidModel<?> model, float[] values) {
      int i = 0;

      for (ModelPart p : parts(model)) {
         p.x = values[i++];
         p.y = values[i++];
         p.z = values[i++];
         p.xRot = values[i++];
         p.yRot = values[i++];
         p.zRot = values[i++];
      }

      copyToLayers(model);
   }

   public static float[] lerp(float[] from, float[] to, float t) {
      float[] out = new float[SIZE];

      for (int i = 0; i < SIZE; i++) {
         out[i] = Mth.lerp(t, from[i], to[i]);
      }

      return out;
   }

   public static void copyToLayers(HumanoidModel<?> model) {
      model.hat.copyFrom(model.head);
      if (model instanceof PlayerModel<?> playerModel) {
         playerModel.jacket.copyFrom(playerModel.body);
         playerModel.leftSleeve.copyFrom(playerModel.leftArm);
         playerModel.rightSleeve.copyFrom(playerModel.rightArm);
         playerModel.leftPants.copyFrom(playerModel.leftLeg);
         playerModel.rightPants.copyFrom(playerModel.rightLeg);
      }
   }

   /**
    * An arm is busy when something else is posing it on purpose: aiming a bow or crossbow, blocking,
    * using a spyglass or horn, or using any item with it (eating, Iron's spell and weapon poses, ...).
    * The flight pose leaves busy arms alone.
    */
   public static boolean isArmBusy(AbstractClientPlayer player, HumanoidModel<?> model, HumanoidArm arm) {
      HumanoidModel.ArmPose pose = arm == HumanoidArm.RIGHT ? model.rightArmPose : model.leftArmPose;
      if (pose != null && pose != HumanoidModel.ArmPose.EMPTY && pose != HumanoidModel.ArmPose.ITEM) {
         return true;
      } else if (player.isUsingItem()) {
         HumanoidArm usedArm = player.getUsedItemHand() == InteractionHand.MAIN_HAND ? player.getMainArm() : player.getMainArm().getOpposite();
         return usedArm == arm;
      } else {
         return false;
      }
   }

   /** Blends two rigid transforms (rotation and translation only). */
   public static Matrix4f lerp(Matrix4f from, Matrix4f to, float t) {
      Quaternionf rotFrom = from.getNormalizedRotation(new Quaternionf());
      Quaternionf rotTo = to.getNormalizedRotation(new Quaternionf());
      Vector3f posFrom = from.getTranslation(new Vector3f());
      Vector3f posTo = to.getTranslation(new Vector3f());
      return new Matrix4f().translation(posFrom.lerp(posTo, t)).rotate(rotFrom.slerp(rotTo, t));
   }
}
