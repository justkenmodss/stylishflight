package com.imjustkenmods.stylishflying;

import net.minecraft.core.Holder;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.ArmorMaterials;
import net.minecraft.world.item.Item;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModItems {
   public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(StylishFlying.MODID);
   public static final DeferredItem<Item> HORIZONTAL_ARMS_FORWARD_CHESTPLATE = chestplate("horizontal_arms_forward_chestplate", ArmorMaterials.DIAMOND, 33);
   public static final DeferredItem<Item> VERTICAL_ARMS_DOWN_CHESTPLATE = chestplate("vertical_arms_down_chestplate", ArmorMaterials.IRON, 15);
   public static final DeferredItem<Item> HORIZONTAL_ARMS_BACK_CHESTPLATE = chestplate("horizontal_arms_back_chestplate", ArmorMaterials.LEATHER, 5);
   public static final DeferredItem<Item> VERTICAL_ARMS_OUT_CHESTPLATE = chestplate("vertical_arms_out_chestplate", ArmorMaterials.GOLD, 7);
   public static final DeferredItem<Item> VERTICAL_ARMS_FORWARD_CHESTPLATE = chestplate("vertical_arms_forward_chestplate", ArmorMaterials.NETHERITE, 37);
   public static final DeferredItem<Item> HORIZONTAL_ARMS_FORWARD_VARIANT_A_CHESTPLATE = chestplate("horizontal_arms_forward_variant_a_chestplate", ArmorMaterials.DIAMOND, 33);
   public static final DeferredItem<Item> HORIZONTAL_ARMS_FORWARD_VARIANT_B_CHESTPLATE = chestplate("horizontal_arms_forward_variant_b_chestplate", ArmorMaterials.DIAMOND, 33);
   public static final DeferredItem<Item> VERTICAL_ARMS_DOWN_VARIANT_A_CHESTPLATE = chestplate("vertical_arms_down_variant_a_chestplate", ArmorMaterials.DIAMOND, 33);
   public static final DeferredItem<Item> SURFING_POSTURE_CHESTPLATE = chestplate("surfing_posture_chestplate", ArmorMaterials.DIAMOND, 33);

   // Since 1.20.5 durability no longer comes from the armor material, so it is set here
   // to match the vanilla chestplate of the same material.
   private static DeferredItem<Item> chestplate(String name, Holder<ArmorMaterial> material, int durabilityMultiplier) {
      return ITEMS.register(name, () -> {
         Item.Properties properties = new Item.Properties().durability(ArmorItem.Type.CHESTPLATE.getDurability(durabilityMultiplier));
         if (material == ArmorMaterials.NETHERITE) {
            properties.fireResistant();
         }
         return new FlightArmorItem(material, ArmorItem.Type.CHESTPLATE, properties);
      });
   }
}
