package com.imjustkenmods.stylishflying;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import net.neoforged.neoforge.client.settings.KeyConflictContext;
import org.lwjgl.glfw.GLFW;

@EventBusSubscriber(modid = StylishFlying.MODID, bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ModKeybinds {
   public static final String CATEGORY = "key.categories.stylishflying";
   public static final KeyMapping BOOST_KEY = new KeyMapping(
      "key.stylishflying.boost", KeyConflictContext.IN_GAME, InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_LEFT_CONTROL, CATEGORY
   );
   public static final KeyMapping TAKEOFF_KEY = new KeyMapping(
      "key.stylishflying.takeoff", KeyConflictContext.IN_GAME, InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_LEFT_SHIFT, CATEGORY
   );

   @SubscribeEvent
   public static void onKeyRegister(RegisterKeyMappingsEvent event) {
      event.register(BOOST_KEY);
      event.register(TAKEOFF_KEY);
   }
}
