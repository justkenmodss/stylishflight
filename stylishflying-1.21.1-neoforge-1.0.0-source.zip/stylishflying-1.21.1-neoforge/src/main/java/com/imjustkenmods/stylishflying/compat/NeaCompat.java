package com.imjustkenmods.stylishflying.compat;

import com.imjustkenmods.stylishflying.FlightState;
import dev.tr7zw.notenoughanimations.access.PlayerData;
import dev.tr7zw.notenoughanimations.api.BasicAnimation;
import dev.tr7zw.notenoughanimations.api.NotEnoughAnimationsApi;
import dev.tr7zw.notenoughanimations.versionless.animations.BodyPart;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.player.AbstractClientPlayer;

/**
 * Only loaded when Not Enough Animations is installed.
 *
 * NEA poses the model after us, and its own falling, elytra and sprinting animations would replace the
 * flight pose. This tells NEA the flight pose owns those body parts while it is showing. Arms that are
 * busy (eating, aiming, blocking, ...) are left to NEA so its hand animations still play.
 */
final class NeaCompat {
   private NeaCompat() {
   }

   static void register() {
      NotEnoughAnimationsApi.registerAnimation(new FlightPoseAnimation());
      NotEnoughAnimationsApi.refreshEnabledAnimations();
   }

   private static final class FlightPoseAnimation extends BasicAnimation {
      // above NEA's elytra (3000) and held item poses (3100), below aiming (3200) and item swapping (3500)
      private static final int PRIORITY = 3150;
      private final BodyPart[] all = parts(true, true);
      private final BodyPart[] leftOnly = parts(false, true);
      private final BodyPart[] rightOnly = parts(true, false);
      private final BodyPart[] noArms = parts(false, false);

      private static BodyPart[] parts(boolean right, boolean left) {
         return java.util.Arrays.stream(BodyPart.values())
            .filter(p -> (right || !p.name().equals("RIGHT_ARM")) && (left || !p.name().equals("LEFT_ARM")))
            .toArray(BodyPart[]::new);
      }

      @Override
      public boolean isEnabled() {
         return true;
      }

      @Override
      public boolean isValid(AbstractClientPlayer entity, PlayerData data) {
         return FlightState.get(entity.getUUID()).poseDrawn;
      }

      @Override
      public BodyPart[] getBodyParts(AbstractClientPlayer entity, PlayerData data) {
         FlightState state = FlightState.get(entity.getUUID());
         if (state.rightArmBusy) {
            return state.leftArmBusy ? this.noArms : this.leftOnly;
         } else {
            return state.leftArmBusy ? this.rightOnly : this.all;
         }
      }

      @Override
      public int getPriority(AbstractClientPlayer entity, PlayerData data) {
         return PRIORITY;
      }

      @Override
      public void apply(AbstractClientPlayer entity, PlayerData data, PlayerModel<AbstractClientPlayer> model, BodyPart part, float delta, float tickCounter) {
         // the flight pose is already on the model; claiming the part is enough
      }
   }
}
