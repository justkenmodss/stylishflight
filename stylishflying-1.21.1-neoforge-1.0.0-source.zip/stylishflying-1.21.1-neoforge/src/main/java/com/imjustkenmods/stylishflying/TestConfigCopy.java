package com.imjustkenmods.stylishflying;

import java.nio.file.Files;
import java.nio.file.Path;
import net.minecraft.world.level.storage.LevelResource;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.loading.FMLPaths;
import net.neoforged.neoforge.event.server.ServerStartingEvent;

public class TestConfigCopy {
   @SubscribeEvent
   public void onServerStarting(ServerStartingEvent event) {
      Path root = event.getServer().getWorldPath(LevelResource.ROOT);
      Path serverConfig = root.resolve("serverconfig").resolve("stylishflying-server.toml");
      Path defaultConfig = FMLPaths.GAMEDIR.get().resolve("defaultconfigs").resolve("stylishflying-server.toml");

      try {
         if (Files.exists(serverConfig) && !Files.exists(defaultConfig)) {
            Files.createDirectories(defaultConfig.getParent());
            Files.copy(serverConfig, defaultConfig);
         }
      } catch (Exception ignored) {
      }
   }
}
