package com.imjustkenmods.stylishflying;

import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Player;
import net.neoforged.neoforge.network.PacketDistributor;
import net.neoforged.neoforge.network.handling.IPayloadContext;

public record ServerboundBoostPacket(boolean boosting) implements CustomPacketPayload {
   public static final Type<ServerboundBoostPacket> TYPE = new Type<>(ResourceLocation.fromNamespaceAndPath(StylishFlying.MODID, "boost"));
   public static final StreamCodec<ByteBuf, ServerboundBoostPacket> STREAM_CODEC = ByteBufCodecs.BOOL.map(ServerboundBoostPacket::new, ServerboundBoostPacket::boosting);

   @Override
   public Type<ServerboundBoostPacket> type() {
      return TYPE;
   }

   public static void handle(ServerboundBoostPacket packet, IPayloadContext context) {
      Player player = context.player();
      boolean allowed = packet.boosting;
      if (allowed && !CommonEventHandler.hasFlightAccess(player)) {
         allowed = false;
      }

      player.getPersistentData().putBoolean("EF_IsBoosting", allowed);
      PacketDistributor.sendToPlayersTrackingEntity(player, new ClientboundSyncBoostPacket(player.getUUID(), allowed));
   }
}
