package com.imjustkenmods.stylishflying.mixin;

import com.imjustkenmods.stylishflying.CommonEventHandler;
import com.imjustkenmods.stylishflying.FlightAnimType;
import com.imjustkenmods.stylishflying.FlightAnimator;
import com.imjustkenmods.stylishflying.FlightState;
import com.imjustkenmods.stylishflying.PoseBlender;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

// Runs at the end of HumanoidModel.setupAnim: after vanilla and anything injected earlier (Iron's weapon
// poses, for example), and before PlayerModel hands the model to playerAnimator, Not Enough Animations
// and WATUT, which pose on top of it.
@Mixin({HumanoidModel.class})
public class MixinPlayerModel {
   @Inject(
      method = {"setupAnim(Lnet/minecraft/world/entity/LivingEntity;FFFFF)V"},
      at = {@At("TAIL")}
   )
   private void stylishflying$afterSetupAnim(
      LivingEntity entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch, CallbackInfo ci
   ) {
      if (entity instanceof AbstractClientPlayer player) {
         HumanoidModel<?> model = (HumanoidModel<?>)(Object)this;
         // the model is shared by every player, so clear offsets a previous player's pose may have left
         FlightAnimator.resetModel(player, model);
         // ageInTicks is 0 when only the first-person hand is drawn
         if (ageInTicks != 0.0F) {
            FlightState state = FlightState.get(player.getUUID());
            FlightAnimType animType = CommonEventHandler.getAnimType(player);
            float[] before = PoseBlender.capture(model);
            float[] result = before;
            boolean drawn = false;
            if (animType != null && state.isPoseActive(player) && state.renderWeight > 0.0F) {
               float partialTick = Mth.clamp(ageInTicks - (float)player.tickCount, 0.0F, 1.0F);
               state.rightArmBusy = PoseBlender.isArmBusy(player, model, HumanoidArm.RIGHT);
               state.leftArmBusy = PoseBlender.isArmBusy(player, model, HumanoidArm.LEFT);
               float headPitchBefore = model.head.xRot;
               float[] rightArm = stylishflying$rotation(model.rightArm);
               float[] leftArm = stylishflying$rotation(model.leftArm);
               FlightAnimator.applyBones(player, state, animType, partialTick, model);
               // busy arms keep their own pose, turned along with the head so aiming still lines up
               float headTurn = model.head.xRot - headPitchBefore;
               if (state.rightArmBusy) {
                  stylishflying$restore(model.rightArm, rightArm, headTurn);
               }

               if (state.leftArmBusy) {
                  stylishflying$restore(model.leftArm, leftArm, headTurn);
               }

               result = PoseBlender.capture(model);
               if (state.renderWeight < 1.0F) {
                  result = PoseBlender.lerp(before, result, state.renderWeight);
               }

               drawn = true;
            } else {
               state.rightArmBusy = false;
               state.leftArmBusy = false;
            }

            float fade = state.fadeProgress(ageInTicks);
            if (fade >= 0.0F && state.fadeFromBones != null) {
               result = PoseBlender.lerp(state.fadeFromBones, result, fade);
            }

            if (result != before) {
               PoseBlender.write(model, result);
            }

            state.lastBones = result;
            state.poseDrawn = drawn;
         }
      }
   }

   @Unique
   private static float[] stylishflying$rotation(ModelPart part) {
      return new float[]{part.xRot, part.yRot, part.zRot};
   }

   @Unique
   private static void stylishflying$restore(ModelPart part, float[] rotation, float headTurn) {
      part.xRot = rotation[0] + headTurn;
      part.yRot = rotation[1];
      part.zRot = rotation[2];
   }
}
