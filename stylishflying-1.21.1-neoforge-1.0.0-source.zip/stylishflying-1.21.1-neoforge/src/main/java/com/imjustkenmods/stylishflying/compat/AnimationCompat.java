package com.imjustkenmods.stylishflying.compat;

import com.imjustkenmods.stylishflying.ModClientConfig;
import com.mojang.logging.LogUtils;
import net.minecraft.client.player.AbstractClientPlayer;
import net.neoforged.fml.ModList;
import org.slf4j.Logger;

/**
 * Entry point for other animation mods. Each optional mod is only touched through its own class,
 * which is never loaded unless that mod is installed.
 */
public final class AnimationCompat {
   private static final Logger LOGGER = LogUtils.getLogger();
   private static boolean playerAnimator = ModList.get().isLoaded("playeranimator");
   private static boolean neaPending = ModList.get().isLoaded("notenoughanimations");

   private AnimationCompat() {
   }

   /**
    * Whether the flight pose should fade out because another mod is animating this player through
    * playerAnimator (emotes, combat rolls, spell casting, weapon attacks, ...).
    */
   public static boolean shouldYield(AbstractClientPlayer player) {
      if (!playerAnimator || !ModClientConfig.YIELD_TO_PLAYER_ANIMATOR.get()) {
         return false;
      } else {
         try {
            int parts = PlayerAnimatorCompat.drivenParts(player);
            if ((parts & PlayerAnimatorCompat.FULL_BODY) != 0) {
               return true;
            } else {
               return (parts & PlayerAnimatorCompat.UPPER_BODY) != 0 && ModClientConfig.YIELD_TO_ARM_ANIMATIONS.get();
            }
         } catch (Throwable e) {
            playerAnimator = false;
            LOGGER.warn("Stylish Flying: playerAnimator support turned off, its API did not match", e);
            return false;
         }
      }
   }

   /** Called every client tick; registers with Not Enough Animations once it has finished loading. */
   public static void clientTick() {
      if (neaPending) {
         neaPending = false;

         try {
            NeaCompat.register();
         } catch (Throwable e) {
            LOGGER.warn("Stylish Flying: Not Enough Animations support turned off, its API did not match", e);
         }
      }
   }
}
