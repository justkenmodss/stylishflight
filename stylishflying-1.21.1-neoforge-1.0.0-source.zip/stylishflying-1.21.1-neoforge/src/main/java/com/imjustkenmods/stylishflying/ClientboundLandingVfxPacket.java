package com.imjustkenmods.stylishflying;

import io.netty.buffer.ByteBuf;
import java.util.UUID;
import net.minecraft.core.UUIDUtil;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.neoforge.network.handling.IPayloadContext;

public record ClientboundLandingVfxPacket(UUID uuid, double impactStrength) implements CustomPacketPayload {
   public static final Type<ClientboundLandingVfxPacket> TYPE = new Type<>(ResourceLocation.fromNamespaceAndPath(StylishFlying.MODID, "landing_vfx"));
   public static final StreamCodec<ByteBuf, ClientboundLandingVfxPacket> STREAM_CODEC = StreamCodec.composite(
      UUIDUtil.STREAM_CODEC, ClientboundLandingVfxPacket::uuid,
      ByteBufCodecs.DOUBLE, ClientboundLandingVfxPacket::impactStrength,
      ClientboundLandingVfxPacket::new
   );

   @Override
   public Type<ClientboundLandingVfxPacket> type() {
      return TYPE;
   }

   public static void handle(ClientboundLandingVfxPacket packet, IPayloadContext context) {
      Player p = context.player().level().getPlayerByUUID(packet.uuid);
      if (p != null) {
         double impactStrength = packet.impactStrength;
         double px = p.getX();
         double py = p.getY();
         double pz = p.getZ();
         if (ModConfigManager.LANDING_ENABLE_VFX.get()) {
            int ringCount = 16 + (int)(impactStrength * 8.0);
            double ringRadius = 0.3;
            double ringSpeed = 0.15 + impactStrength * 0.12;

            for (int i = 0; i < ringCount; i++) {
               double angle = Math.toRadians((double)i * (360.0 / (double)ringCount));
               double vx = Math.cos(angle) * ringSpeed;
               double vz = Math.sin(angle) * ringSpeed;
               p.level().addParticle(ParticleTypes.CLOUD, px + Math.cos(angle) * ringRadius, py + 0.15, pz + Math.sin(angle) * ringRadius, vx, 0.02, vz);
               if (i % 2 == 0) {
                  p.level().addParticle(
                     ParticleTypes.POOF,
                     px + Math.cos(angle) * ringRadius * 0.5,
                     py + 0.1,
                     pz + Math.sin(angle) * ringRadius * 0.5,
                     vx * 0.6,
                     0.05,
                     vz * 0.6
                  );
               }
            }

            for (int i = 0; i < 12; i++) {
               double angle = Math.toRadians((double)i * 30.0 + p.getRandom().nextDouble() * 10.0);
               double dist = 0.3 + p.getRandom().nextDouble() * 1.5;
               double speed = 0.03 + impactStrength * 0.02;
               p.level().addParticle(
                  ParticleTypes.CAMPFIRE_COSY_SMOKE,
                  px + Math.cos(angle) * dist,
                  py + 0.05,
                  pz + Math.sin(angle) * dist,
                  Math.cos(angle) * speed,
                  0.01,
                  Math.sin(angle) * speed
               );
            }

            BlockState groundBlock = p.level().getBlockState(p.blockPosition().below());
            if (!groundBlock.isAir()) {
               int debrisCount = 10 + (int)(impactStrength * 10.0);

               for (int i = 0; i < debrisCount; i++) {
                  double ox = (p.getRandom().nextDouble() - 0.5) * 1.5;
                  double oz = (p.getRandom().nextDouble() - 0.5) * 1.5;
                  double vx = (p.getRandom().nextDouble() - 0.5) * 0.15;
                  double vy = 0.05 + p.getRandom().nextDouble() * 0.2;
                  double vz = (p.getRandom().nextDouble() - 0.5) * 0.15;
                  p.level().addParticle(new BlockParticleOption(ParticleTypes.BLOCK, groundBlock), px + ox, py + 0.1, pz + oz, vx, vy, vz);
               }
            }
         }

         if (ModConfigManager.LANDING_ENABLE_SOUND.get()) {
            p.level().playLocalSound(
               px, py, pz, SoundEvents.GENERIC_EXPLODE.value(), SoundSource.PLAYERS,
               0.8F + (float)(impactStrength * 0.3), 0.6F + (float)(impactStrength * 0.1), false
            );
            p.level().playLocalSound(px, py, pz, SoundEvents.ANVIL_LAND, SoundSource.PLAYERS, 0.5F, 0.4F, false);
         }
      }
   }
}
