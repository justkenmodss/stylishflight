package com.imjustkenmods.stylishflying;

import java.util.Arrays;
import java.util.List;
import net.neoforged.neoforge.common.ModConfigSpec;
import net.neoforged.neoforge.common.ModConfigSpec.BooleanValue;
import net.neoforged.neoforge.common.ModConfigSpec.Builder;
import net.neoforged.neoforge.common.ModConfigSpec.ConfigValue;
import net.neoforged.neoforge.common.ModConfigSpec.DoubleValue;
import net.neoforged.neoforge.common.ModConfigSpec.EnumValue;
import net.neoforged.neoforge.common.ModConfigSpec.IntValue;

public class ModConfigManager {
   public static final Builder BUILDER = new Builder();
   public static final ConfigValue<List<? extends String>> horizontal_arms_forward_ARMORS;
   public static final ConfigValue<List<? extends String>> vertical_arms_down_ARMORS;
   public static final ConfigValue<List<? extends String>> horizontal_arms_back_ARMORS;
   public static final ConfigValue<List<? extends String>> LEVITATE_ARMORS;
   public static final ConfigValue<List<? extends String>> FORWARD_ARMORS;
   public static final ConfigValue<List<? extends String>> HORIZONTAL_ARMS_FORWARD_VARIANT_A_ARMORS;
   public static final ConfigValue<List<? extends String>> HORIZONTAL_ARMS_FORWARD_VARIANT_B_ARMORS;
   public static final ConfigValue<List<? extends String>> VERTICAL_ARMS_DOWN_VARIANT_A_ARMORS;
   public static final ConfigValue<List<? extends String>> SURFING_POSTURE_ARMORS;
   public static final ConfigValue<List<? extends String>> FLIGHT_UPGRADES;
   public static final DoubleValue STAGE_1_SPEED;
   public static final DoubleValue STAGE_2_SPEED;
   public static final ConfigValue<List<? extends String>> CUSTOM_SPEEDS;
   public static final BooleanValue ENABLE_CURIOS_SUPPORT;
   public static final ConfigValue<List<? extends String>> CURIOS_FLIGHT_ITEMS;
   public static final BooleanValue ENABLE_NOFALL;
   public static final BooleanValue ENABLE_DEFAULT_FLIGHT;
   public static final BooleanValue ITEMS_GRANT_FLIGHT;
   public static final EnumValue<FlightAnimType> DEFAULT_FLIGHT_ANIMATION;
   public static final BooleanValue ENABLE_POTION_FLIGHT;
   public static final EnumValue<FlightAnimType> POTION_FLIGHT_ANIMATION;
   public static final ConfigValue<List<? extends String>> FLIGHT_POTIONS;
   public static final BooleanValue ENABLE_FLIGHT_COST;
   public static final EnumValue<ModConfigManager.CostType> FLIGHT_COST_TYPE;
   public static final IntValue FLIGHT_COST_AMOUNT;
   public static final BooleanValue COST_ONLY_ON_BOOST;
   public static final BooleanValue ENABLE_GROUNDED;
   public static final IntValue GROUNDED_DURATION_TICKS;
   public static final ConfigValue<List<? extends String>> GROUNDED_ARMOR_OVERRIDES;
   public static final BooleanValue ENABLE_FALL_ANIMATION;
   public static final BooleanValue ENABLE_LANDING_ANIMATION;
   public static final BooleanValue ENABLE_LANDING_SHOCKWAVE;
   public static final BooleanValue LANDING_ENABLE_VFX;
   public static final BooleanValue LANDING_ENABLE_SOUND;
   public static final DoubleValue LANDING_DAMAGE;
   public static final DoubleValue LANDING_RADIUS;
   public static final DoubleValue LANDING_KNOCKBACK;
   public static final ConfigValue<List<? extends String>> LANDING_ARMOR_OVERRIDES;
   public static final BooleanValue ENABLE_TAKEOFF;
   public static final BooleanValue TAKEOFF_ENABLE_VFX;
   public static final BooleanValue TAKEOFF_ENABLE_SOUND;
   public static final DoubleValue TAKEOFF_HEIGHT;
   public static final DoubleValue TAKEOFF_SPEED;
   public static final ConfigValue<List<? extends String>> TAKEOFF_ARMOR_OVERRIDES;
   public static final BooleanValue ENABLE_OVERHEAT;
   public static final IntValue OVERHEAT_MAX_HEAT;
   public static final ConfigValue<List<? extends String>> OVERHEAT_ARMOR_OVERRIDES;
   public static final BooleanValue ENABLE_KINETIC_DESTRUCTION;
   public static final ConfigValue<List<? extends String>> KINETIC_BLOCKS;
   public static final BooleanValue ENABLE_DIMENSION_RESTRICTION;
   public static final BooleanValue DIMENSION_IS_WHITELIST;
   public static final ConfigValue<List<? extends String>> DIMENSION_LIST;
   public static final ModConfigSpec SPEC;

   static {
      BUILDER.comment(
            new String[]{
               "======================================================================",
               "                      FLIGHT ANIMATIONS & TAGS",
               "======================================================================",
               "This mod natively supports Data-Driven Tags! If you are a Modpack Maker,",
               "you DO NOT need to add every single item to this config file.",
               "Instead, use KubeJS, CraftTweaker, or Data Packs to add items to our tags:",
               "",
               "  Tags available:",
               "    #stylishflying:horizontal_arms_forward_animations",
               "    #stylishflying:vertical_arms_down_animations",
               "    #stylishflying:horizontal_arms_back_animations",
               "    #stylishflying:vertical_arms_out_animations",
               "    #stylishflying:vertical_arms_forward_animations",
               "    #stylishflying:flight_upgrades",
               "",
               "  Example using KubeJS (put in server_scripts/):",
               "    ServerEvents.tags('item', event => {",
               "        event.add('stylishflying:horizontal_arms_forward_animations', 'minecraft:diamond_chestplate')",
               "        event.add('stylishflying:vertical_arms_down_animations', 'mekanism:mekasuit_bodyarmor')",
               "        event.add('stylishflying:flight_upgrades', 'pneumaticcraft:jet_boots_upgrade')",
               "    })",
               "",
               "  Example using a Data Pack (data/stylishflying/tags/item/horizontal_arms_forward_animations.json):",
               "    { \"replace\": false, \"values\": [\"minecraft:diamond_chestplate\"] }",
               "======================================================================"
            }
         )
         .push("Flight Animations");
      horizontal_arms_forward_ARMORS = BUILDER.comment(
            new String[]{
               "Armors that use the horizontal_arms_forward flight animation.",
               "Example: [\"minecraft:diamond_chestplate\", \"vertical_arms_down:mk50_chestplate\"]"
            }
         )
         .defineListAllowEmpty(
            Arrays.asList("horizontal_arms_forward_armors"), () -> Arrays.asList("stylishflying:horizontal_arms_forward_chestplate"), o -> o instanceof String
         );
      vertical_arms_down_ARMORS = BUILDER.comment(
            new String[]{"Armors that use the Vertical Arms Down flight animation.", "Example: [\"mekanism:mekasuit_bodyarmor\"]"}
         )
         .defineListAllowEmpty(
            Arrays.asList("vertical_arms_down_armors"), () -> Arrays.asList("stylishflying:vertical_arms_down_chestplate"), o -> o instanceof String
         );
      horizontal_arms_back_ARMORS = BUILDER.comment(
            new String[]{"Armors that use the horizontal_arms_back flight animation.", "Example: [\"create:copper_backtank\"]"}
         )
         .defineListAllowEmpty(
            Arrays.asList("horizontal_arms_back_armors"), () -> Arrays.asList("stylishflying:horizontal_arms_back_chestplate"), o -> o instanceof String
         );
      LEVITATE_ARMORS = BUILDER.comment(
            new String[]{"Armors that use the Levitate flight animation.", "Example: [\"botania:terrasteel_chestplate\"]"}
         )
         .defineListAllowEmpty(
            Arrays.asList("vertical_arms_out_armors"), () -> Arrays.asList("stylishflying:vertical_arms_out_chestplate"), o -> o instanceof String
         );
      FORWARD_ARMORS = BUILDER.comment(
            new String[]{"Armors that use the Forward Arms flight animation.", "Example: [\"minecraft:elytra\"]"}
         )
         .defineListAllowEmpty(
            Arrays.asList("vertical_arms_forward_armors"), () -> Arrays.asList("stylishflying:vertical_arms_forward_chestplate"), o -> o instanceof String
         );
      HORIZONTAL_ARMS_FORWARD_VARIANT_A_ARMORS = BUILDER.comment(
            "Armors that use the variant_a horizontal_arms_forward flight animation."
         )
         .defineListAllowEmpty(Arrays.asList("horizontal_arms_forward_variant_a_armors"), () -> Arrays.asList(), o -> o instanceof String);
      HORIZONTAL_ARMS_FORWARD_VARIANT_B_ARMORS = BUILDER.comment(
            "Armors that use the variant_b horizontal_arms_forward flight animation."
         )
         .defineListAllowEmpty(Arrays.asList("horizontal_arms_forward_variant_b_armors"), () -> Arrays.asList(), o -> o instanceof String);
      VERTICAL_ARMS_DOWN_VARIANT_A_ARMORS = BUILDER.comment(
            "Armors that use the variant_c variant_c flight animation."
         )
         .defineListAllowEmpty(Arrays.asList("vertical_arms_down_variant_a_armors"), () -> Arrays.asList(), o -> o instanceof String);
      SURFING_POSTURE_ARMORS = BUILDER.comment(
            "Armors that use the variant_d Surfing Posture flight animation."
         )
         .defineListAllowEmpty(Arrays.asList("surfing_posture_armors"), () -> Arrays.asList(), o -> o instanceof String);
      FLIGHT_UPGRADES = BUILDER.comment(
            new String[]{
               "List of Upgrade IDs (or Armor IDs) that grant creative flight.",
               "Items in this list grant flight but do NOT set an animation style.",
               "Example: [\"pneumaticcraft:jet_boots_upgrade\", \"cyclic:charm_wing\"]"
            }
         )
         .defineListAllowEmpty(Arrays.asList("flight_upgrades"), () -> Arrays.asList("pneumaticcraft:jet_boots_upgrade"), o -> o instanceof String);
      BUILDER.pop();

      BUILDER.push("Flight Speed");
      STAGE_1_SPEED = BUILDER.comment(
            "Flight speed for Stage 1 (default flight). Vanilla creative flight speed is roughly 0.05. (Default: 0.10)"
         )
         .defineInRange("stage_1_speed", 0.1, 0.0, 5.0);
      STAGE_2_SPEED = BUILDER.comment(
            "Flight speed for Stage 2 (boost flight). Activated by pressing the boost key. (Default: 0.45)"
         )
         .defineInRange("stage_2_speed", 0.45, 0.0, 10.0);
      CUSTOM_SPEEDS = BUILDER.comment(
            new String[]{
               "Custom speeds per armor. If an armor is NOT on this list, it uses defaults above.",
               "",
               "Format: \"modid:item | stage_1_speed | stage_2_speed\"",
               "",
               "Examples:",
               "  \"stylishflying:horizontal_arms_forward_chestplate | 0.25 | 1.8\"",
               "  \"mekanism:mekasuit_bodyarmor | 0.45 | 1.0\"",
               "  \"minecraft:diamond_chestplate | 0.08 | 0.3\""
            }
         )
         .defineList("custom_speeds", Arrays.asList(), obj -> obj instanceof String);
      BUILDER.pop();

      BUILDER.push("Default Flight Options");
      ENABLE_CURIOS_SUPPORT = BUILDER.comment(
            "If true, the mod will scan Curios/Baubles slots for flight armors and upgrades. Disable to only check vanilla armor slots."
         )
         .define("enable_curios_support", true);
      CURIOS_FLIGHT_ITEMS = BUILDER.comment(
            new String[]{
               "Custom items (Curios, Baubles, or any slot) that grant flight with a specific animation and speed.",
               "Works for ANY equipped item — Curios slots, armor slots, held items, etc.",
               "",
               "Format: \"modid:item | ANIM_TYPE | stage1_speed | stage2_speed\"",
               "",
               "  stage1_speed = normal hovering speed (vanilla creative is ~0.05)",
               "  stage2_speed = boost speed when pressing the boost key",
               "",
               "Animation types available:",
               "  HORIZONTAL_ARMS_FORWARD            (Superman pose)",
               "  HORIZONTAL_ARMS_FORWARD_VARIANT_A  (Variant A)",
               "  HORIZONTAL_ARMS_FORWARD_VARIANT_B  (Variant B)",
               "  HORIZONTAL_ARMS_BACK               (Arms-back pose)",
               "  VERTICAL_ARMS_DOWN                 (Iron Man descending)",
               "  VERTICAL_ARMS_DOWN_VARIANT_A       (Variant A)",
               "  VERTICAL_ARMS_OUT                  (Levitation/Angel pose)",
               "  VERTICAL_ARMS_FORWARD              (Elytra-like upright)",
               "  SURFING_POSTURE                    (Surfing/board pose)",
               "",
               "Examples:",
               "  \"extrautils2:golden_angel_ring | HORIZONTAL_ARMS_FORWARD_VARIANT_A | 0.15 | 0.60\"",
               "  \"extrautils2:angel_ring        | HORIZONTAL_ARMS_FORWARD_VARIANT_B | 0.20 | 0.80\"",
               "  \"botania:black_lotus           | VERTICAL_ARMS_OUT                 | 0.10 | 0.45\"",
               "  \"cyclic:charm_wing             | HORIZONTAL_ARMS_FORWARD           | 0.12 | 0.55\""
            }
         )
         .defineList("curios_flight_items", Arrays.asList(), obj -> obj instanceof String);
      ENABLE_NOFALL = BUILDER.comment(
            new String[]{
               "If true, players wearing items/potions with flight tags will NOT take fall damage.",
               "If false, this mod won't interfere and fall damage will be handled by vanilla or other mods."
            }
         )
         .define("enable_nofall", true);
      ITEMS_GRANT_FLIGHT = BUILDER.comment(
            new String[]{
               "If true, the items, tags and potions listed in this config give survival players flight.",
               "If false, Stylish Flying never gives flight itself: its animations, boost, overheat, landings and",
               "no-fall only apply to players who can already fly (creative, spectator, or NeoForge's creative flight",
               "attribute, which other flight mods use). The item lists then only pick the animation style."
            }
         )
         .define("items_grant_flight", false);
      ENABLE_DEFAULT_FLIGHT = BUILDER.comment("Apply flight physics to ANY player flying (like Creative Mode/Angel Rings).")
         .define("enable_default_flight", true);
      DEFAULT_FLIGHT_ANIMATION = BUILDER.comment("Animation style when ENABLE_DEFAULT_FLIGHT is true.")
         .defineEnum("default_flight_animation", FlightAnimType.VERTICAL_ARMS_FORWARD);
      BUILDER.pop();

      BUILDER.push("Potion Flight Options");
      ENABLE_POTION_FLIGHT = BUILDER.comment("Apply animations when a configured flight potion effect is active.")
         .define("enable_potion_flight", true);
      POTION_FLIGHT_ANIMATION = BUILDER.comment("Animation style for flight potions.")
         .defineEnum("potion_flight_animation", FlightAnimType.VERTICAL_ARMS_OUT);
      FLIGHT_POTIONS = BUILDER.comment(
            new String[]{"List of MobEffect IDs that simulate creative flight.", "Examples: alexsmobs:flight, cyclic:flight, apotheosis:flying"}
         )
         .defineListAllowEmpty(
            Arrays.asList("flight_potions"), () -> Arrays.asList("alexsmobs:flight", "cyclic:flight", "apotheosis:flying"), o -> o instanceof String
         );
      BUILDER.pop();

      BUILDER.push("Flight Costs and Balance");
      ENABLE_FLIGHT_COST = BUILDER.comment("Should flying consume resources? (Useful for modpacks)")
         .define("enable_flight_cost", false);
      FLIGHT_COST_TYPE = BUILDER.comment(
            "What resource should be consumed? Options: NONE, HUNGER, XP, HEALTH, FE_ENERGY, DURABILITY"
         )
         .defineEnum("flight_cost_type", ModConfigManager.CostType.HUNGER);
      FLIGHT_COST_AMOUNT = BUILDER.comment("Amount of the resource consumed per second.")
         .defineInRange("flight_cost_amount", 1, 0, 100000);
      COST_ONLY_ON_BOOST = BUILDER.comment(
            "If true, costs are only applied while flying fast (Stage 2 Boost). If false, simply hovering costs resources."
         )
         .define("cost_only_on_boost", true);
      BUILDER.pop();

      BUILDER.push("Mechanics: Grounded (Combat Nerf)");
      ENABLE_GROUNDED = BUILDER.comment("Disable flight for a few seconds if taking damage from entities.")
         .define("enable_grounded", true);
      GROUNDED_DURATION_TICKS = BUILDER.comment("Default duration in ticks (20 = 1s) to disable flight.")
         .defineInRange("grounded_duration_ticks", 60, 0, 1000);
      GROUNDED_ARMOR_OVERRIDES = BUILDER.comment(
            new String[]{
               "Override grounding duration per armor. Set to 0 = immune to grounding.",
               "",
               "Format: \"modid:item | duration_ticks\"",
               "",
               "Examples:",
               "  \"stylishflying:horizontal_arms_forward_chestplate | 20\"",
               "  \"mekanism:mekasuit_bodyarmor | 0\""
            }
         )
         .defineList("grounded_armor_overrides", Arrays.asList(), obj -> obj instanceof String);
      BUILDER.pop();

      BUILDER.push("Visual Animations");
      ENABLE_FALL_ANIMATION = BUILDER.comment("If true, enables the freefall/starfish animation when falling from high places.")
         .define("enable_fall_animation", false);
      ENABLE_LANDING_ANIMATION = BUILDER.comment("If true, enables the superhero landing animation when hitting the ground.")
         .define("enable_landing_animation", false);
      BUILDER.pop();

      BUILDER.push("Mechanics: Superhero Landing");
      ENABLE_LANDING_SHOCKWAVE = BUILDER.comment("Create a shockwave when hitting the ground at high speed.")
         .define("enable_landing_shockwave", false);
      LANDING_ENABLE_VFX = BUILDER.comment("Enable the visual effects (particles) for the landing.")
         .define("landing_enable_vfx", true);
      LANDING_ENABLE_SOUND = BUILDER.comment("Enable the sound effects for the landing.").define("landing_enable_sound", true);
      LANDING_DAMAGE = BUILDER.comment("Default shockwave damage.").defineInRange("landing_damage", 5.0, 0.0, 100.0);
      LANDING_RADIUS = BUILDER.comment("Default shockwave radius in blocks.").defineInRange("landing_radius", 5.0, 0.0, 50.0);
      LANDING_KNOCKBACK = BUILDER.comment("Default shockwave knockback multiplier.")
         .defineInRange("landing_knockback", 1.0, 0.0, 10.0);
      LANDING_ARMOR_OVERRIDES = BUILDER.comment(
            new String[]{
               "Override landing shockwave per armor.",
               "",
               "Format: \"modid:item | true/false | damage | radius | knockback\"",
               "",
               "Examples:",
               "  \"stylishflying:horizontal_arms_forward_chestplate | true | 10.0 | 8.0 | 2.0\"",
               "  \"minecraft:diamond_chestplate | false | 0 | 0 | 0\""
            }
         )
         .defineList("landing_armor_overrides", Arrays.asList(), obj -> obj instanceof String);
      BUILDER.pop();

      BUILDER.push("Mechanics: Sonic Takeoff");
      ENABLE_TAKEOFF = BUILDER.comment("Hold Sneak on the ground to charge a super jump. Release Sneak to launch.")
         .define("enable_takeoff", false);
      TAKEOFF_ENABLE_VFX = BUILDER.comment("Enable the visual effects (particles) for the takeoff.")
         .define("takeoff_enable_vfx", true);
      TAKEOFF_ENABLE_SOUND = BUILDER.comment("Enable the sound effects for the takeoff.").define("takeoff_enable_sound", true);
      TAKEOFF_HEIGHT = BUILDER.comment("Takeoff launch height multiplier.").defineInRange("takeoff_height", 2.0, 0.0, 10.0);
      TAKEOFF_SPEED = BUILDER.comment("Takeoff launch speed.").defineInRange("takeoff_speed", 2.5, 0.0, 10.0);
      TAKEOFF_ARMOR_OVERRIDES = BUILDER.comment(
            new String[]{
               "Override takeoff height/speed per armor.",
               "",
               "Format: \"modid:item | height | speed\"",
               "",
               "Examples:",
               "  \"stylishflying:horizontal_arms_forward_chestplate | 4.0 | 5.0\"",
               "  \"minecraft:diamond_chestplate | 1.5 | 1.0\""
            }
         )
         .defineList("takeoff_armor_overrides", Arrays.asList(), obj -> obj instanceof String);
      BUILDER.pop();

      BUILDER.push("Mechanics: Overheat");
      ENABLE_OVERHEAT = BUILDER.comment("Boost generates heat. Max heat disables boost until cooled down.")
         .define("enable_overheat", true);
      OVERHEAT_MAX_HEAT = BUILDER.comment("Maximum heat capacity (higher = longer boost before overheat).")
         .defineInRange("overheat_max_heat", 200, 10, 10000);
      OVERHEAT_ARMOR_OVERRIDES = BUILDER.comment(
            new String[]{
               "Override max heat per armor.",
               "",
               "Format: \"modid:item | max_heat\"",
               "",
               "Examples:",
               "  \"stylishflying:horizontal_arms_forward_chestplate | 500\"",
               "  \"mekanism:mekasuit_bodyarmor | 1000\""
            }
         )
         .defineList("overheat_armor_overrides", Arrays.asList(), obj -> obj instanceof String);
      BUILDER.pop();

      BUILDER.push("Mechanics: Kinetic Destruction");
      ENABLE_KINETIC_DESTRUCTION = BUILDER.comment(
            new String[]{"Smash through certain blocks when boosting at high speed.", "Blocks are instantly destroyed when you fly through them."}
         )
         .define("enable_kinetic_destruction", true);
      KINETIC_BLOCKS = BUILDER.comment(
            new String[]{
               "List of blocks or block tags to smash through.",
               "Use # prefix for tags (e.g. #minecraft:leaves).",
               "",
               "Examples:",
               "  \"minecraft:glass\"",
               "  \"minecraft:glass_pane\"",
               "  \"#minecraft:leaves\"",
               "  \"minecraft:cobweb\""
            }
         )
         .defineList("kinetic_blocks", Arrays.asList("minecraft:glass", "minecraft:glass_pane", "#minecraft:leaves"), obj -> obj instanceof String);
      BUILDER.pop();

      BUILDER.push("Dimension Restrictions");
      ENABLE_DIMENSION_RESTRICTION = BUILDER.comment("Enable dimension restrictions for Stylish Flying?")
         .define("enable_dimension_restriction", false);
      DIMENSION_IS_WHITELIST = BUILDER.comment(
            "If true, the list below is a Whitelist (ONLY allow flight in these). If false, it's a Blacklist (Block flight in these)."
         )
         .define("dimension_is_whitelist", false);
      DIMENSION_LIST = BUILDER.comment(
            new String[]{"List of Dimension IDs.", "Examples: minecraft:the_end, twilightforest:twilight_forest"}
         )
         .defineListAllowEmpty(Arrays.asList("dimension_list"), () -> Arrays.asList("minecraft:the_end"), o -> o instanceof String);
      BUILDER.pop();

      SPEC = BUILDER.build();
   }

   public enum CostType {
      HUNGER,
      XP,
      HEALTH,
      FE_ENERGY,
      DURABILITY,
      NONE;
   }
}
