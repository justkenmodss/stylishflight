package com.imjustkenmods.stylishflying;

import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

public class CameraRollManager {
   private static final double ROLL_DIVISOR = 4.0;
   public static float roll = 0.0F;
   public static float prevRoll = 0.0F;
   private static float rollTarget = 0.0F;

   public static void update(Player player, FlightState state) {
      prevRoll = roll;
      rollTarget *= 0.4F;
      float boostTimer = state.boostTimer;
      if (boostTimer <= 0.0F) {
         roll = (rollTarget + roll * 2.0F) / 3.0F;
      } else {
         float f = FlightState.curve(boostTimer);
         Vec3 look = player.getViewVector(1.0F);
         Vec3 motion = state.motion;
         double vel = motion.x * motion.x + motion.z * motion.z;
         double dir = look.x * look.x + look.z * look.z;
         if (vel > 0.0 && dir > 0.0) {
            double dot = (motion.x * look.x + motion.z * look.z) / Math.sqrt(vel * dir);
            double cross = motion.x * look.z - motion.z * look.x;
            rollTarget = (float)(Math.signum(cross) * Math.acos((double)Mth.clamp((float)dot, -1.0F, 1.0F)) * 180.0 / Math.PI * Math.min(vel, 1.0) / 4.0);
         }

         if (Float.isNaN(rollTarget)) {
            rollTarget = 0.0F;
         }

         rollTarget = f * Mth.clamp(rollTarget, -90.0F, 90.0F);
         roll = (rollTarget + roll * 2.0F) / 3.0F;
      }
   }

   public static float getInterpolatedRoll(float partialTick) {
      return Mth.lerp(partialTick, prevRoll, roll);
   }

   public static void reset() {
      roll = 0.0F;
      prevRoll = 0.0F;
      rollTarget = 0.0F;
   }
}
