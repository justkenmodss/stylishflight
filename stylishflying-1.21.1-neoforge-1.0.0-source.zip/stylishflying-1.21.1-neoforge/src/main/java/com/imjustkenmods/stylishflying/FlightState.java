package com.imjustkenmods.stylishflying;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;

public class FlightState {
   private static final Map<UUID, FlightState> STATES = new HashMap<>();
   public float flightTimer = 0.0F;
   public float prevFlightTimer = 0.0F;
   public float boostTimer = 0.0F;
   public float prevBoostTimer = 0.0F;
   public boolean isBoosting = false;
   public float heat = 0.0F;
   public boolean overheated = false;
   public float takeoffCharge = 0.0F;
   public boolean wasFlying = false;
   public double prevDeltaY = 0.0;
   public float landingTimer = 0.0F;
   public float prevLandingTimer = 0.0F;
   public float fallTimer = 0.0F;
   public float prevFallTimer = 0.0F;
   public float freefallTimer = 0.0F;
   public float prevFreefallTimer = 0.0F;
   public float braceTimer = 0.0F;
   public float prevBraceTimer = 0.0F;
   public int fallTicks = 0;
   public Vec3 motion = Vec3.ZERO;
   public Vec3 prevMotion = Vec3.ZERO;

   // Render-side blending (client only). Times are in ticks, measured with the entity's bob value
   // (tickCount + partialTick), which both the renderer and the model receive each frame.
   public int fadeRequest = 0;
   public float fadeStart = -1.0F;
   public float fadeLength = 0.0F;
   public float[] fadeFromBones = null;
   public final Matrix4f fadeFromBody = new Matrix4f();
   public float[] lastBones = null;
   public final Matrix4f lastBody = new Matrix4f();
   public FlightAnimType lastAnimType = null;
   public float yieldAmount = 0.0F;
   public float yieldTime = -1.0F;
   public float renderWeight = 1.0F;
   public boolean poseDrawn = false;
   public boolean rightArmBusy = false;
   public boolean leftArmBusy = false;

   public static FlightState get(UUID uuid) {
      return STATES.computeIfAbsent(uuid, k -> new FlightState());
   }

   public static void remove(UUID uuid) {
      STATES.remove(uuid);
   }

   public void tick(boolean flying, boolean boosting, Player player) {
      this.isBoosting = boosting;
      this.prevFlightTimer = this.flightTimer;
      this.prevBoostTimer = this.boostTimer;
      this.prevMotion = this.motion;
      if (player.level().isClientSide() && player != Minecraft.getInstance().player) {
         this.motion = new Vec3(player.getX() - player.xo, player.getY() - player.yo, player.getZ() - player.zo);
      } else {
         this.motion = player.getDeltaMovement();
      }

      float flightStep = 0.1F;
      float boostStep = 0.125F;
      if (flying) {
         this.flightTimer = Math.min(1.0F, this.flightTimer + flightStep);
      } else {
         this.flightTimer = Math.max(0.0F, this.flightTimer - flightStep);
      }

      if (boosting) {
         this.boostTimer = Math.min(1.0F, this.boostTimer + boostStep);
      } else {
         this.boostTimer = Math.max(0.0F, this.boostTimer - boostStep);
      }

      if (!player.onGround() && this.motion.y < -0.1) {
         this.fallTicks++;
      } else {
         this.fallTicks = 0;
      }

      boolean isHighUp = true;

      for (int i = 0; i <= 30; i++) {
         BlockPos bp = player.blockPosition().below(i);
         if (!player.level().getBlockState(bp).isAir()) {
            isHighUp = false;
            break;
         }
      }

      this.prevFallTimer = this.fallTimer;
      this.prevFreefallTimer = this.freefallTimer;
      this.prevBraceTimer = this.braceTimer;
      boolean hasAnim = CommonEventHandler.hasFlightAccess(player);
      if (hasAnim && !flying && this.wasFlying && !player.onGround() && this.motion.y < -0.1) {
         this.fallTimer = Math.min(1.0F, this.fallTimer + 0.1F);
      } else {
         this.fallTimer = Math.max(0.0F, this.fallTimer - 0.1F);
      }

      boolean freefallCondition = hasAnim
         && !flying
         && !this.wasFlying
         && this.motion.y < -0.1
         && (this.fallTicks > 8 && isHighUp || this.fallTicks > 30)
         && ModConfigManager.ENABLE_FALL_ANIMATION.get();
      if (freefallCondition) {
         this.freefallTimer = Math.min(1.0F, this.freefallTimer + 0.1F);
         double dist = 8.0;

         for (int ix = 1; ix <= 8; ix++) {
            if (!player.level().getBlockState(player.blockPosition().below(ix)).isAir()) {
               dist = (double)ix;
               break;
            }
         }

         if (dist < 8.0) {
            float targetBrace = (float)Math.max(0.0, 1.0 - dist / 8.0);
            this.braceTimer = Math.max(this.braceTimer, targetBrace);
         } else {
            this.braceTimer = Math.max(0.0F, this.braceTimer - 0.1F);
         }
      } else {
         this.freefallTimer = Math.max(0.0F, this.freefallTimer - 0.1F);
         this.braceTimer = Math.max(0.0F, this.braceTimer - 0.2F);
      }

      this.prevLandingTimer = this.landingTimer;
      boolean hardImpact = hasAnim
         && player.onGround()
         && this.prevDeltaY < -0.6
         && (this.wasFlying || this.prevFreefallTimer > 0.0F || this.prevFallTimer > 0.0F)
         && ModConfigManager.ENABLE_LANDING_ANIMATION.get();
      if (hardImpact) {
         // the other poses are cut below, so blend into the landing instead of popping into it
         this.fadeRequest = Math.max(this.fadeRequest, 3);
         this.landingTimer = 1.0F;
      } else if (this.landingTimer > 0.0F) {
         float decay = this.motion.horizontalDistanceSqr() > 0.001 ? 0.1F : 0.05F;
         this.landingTimer = Math.max(0.0F, this.landingTimer - decay);
      }

      if (this.landingTimer > 0.0F) {
         this.flightTimer = 0.0F;
         this.boostTimer = 0.0F;
         this.fallTimer = 0.0F;
         this.freefallTimer = 0.0F;
         this.braceTimer = 0.0F;
         this.prevFlightTimer = 0.0F;
         this.prevBoostTimer = 0.0F;
         this.prevFallTimer = 0.0F;
         this.prevFreefallTimer = 0.0F;
         this.prevBraceTimer = 0.0F;
      }

      this.prevDeltaY = this.motion.y;
      if (flying || player.getAbilities().flying) {
         this.wasFlying = true;
      } else if (player.onGround()) {
         this.wasFlying = false;
      }
   }

   // True while any part of the flight pose is still showing, including while it fades out.
   public boolean isPoseActive(Player player) {
      return CommonEventHandler.isFlyingForAnimation(player)
         || this.flightTimer > 0.0F
         || this.prevFlightTimer > 0.0F
         || this.boostTimer > 0.0F
         || this.prevBoostTimer > 0.0F
         || this.landingTimer > 0.0F
         || this.prevLandingTimer > 0.0F
         || this.fallTimer > 0.0F
         || this.prevFallTimer > 0.0F
         || this.freefallTimer > 0.0F
         || this.prevFreefallTimer > 0.0F;
   }

   // Starts a crossfade from the last drawn pose if one was asked for since the last frame.
   public void startRequestedFade(float now) {
      if (this.fadeRequest > 0) {
         if (this.lastBones != null) {
            this.fadeFromBones = this.lastBones.clone();
            this.fadeFromBody.set(this.lastBody);
            this.fadeStart = now;
            this.fadeLength = (float)this.fadeRequest;
         }

         this.fadeRequest = 0;
      }
   }

   // Progress of the running crossfade (0 = old pose, 1 = new pose), or -1 if none is running.
   public float fadeProgress(float now) {
      if (this.fadeStart < 0.0F || this.fadeLength <= 0.0F) {
         return -1.0F;
      } else if (now < this.fadeStart) {
         this.fadeStart = -1.0F;
         return -1.0F;
      } else {
         float t = (now - this.fadeStart) / this.fadeLength;
         if (t >= 1.0F) {
            this.fadeStart = -1.0F;
            return -1.0F;
         } else {
            return curve(t);
         }
      }
   }

   public static float curve(float x) {
      x = Math.max(0.0F, Math.min(1.0F, x));
      return x * x * (3.0F - 2.0F * x);
   }

   public float getCurvedFlight() {
      return curve(this.flightTimer);
   }

   public float getCurvedBoost() {
      return curve(this.boostTimer);
   }

   public float getFlightInterp(float partialTick) {
      return this.prevFlightTimer + (this.flightTimer - this.prevFlightTimer) * partialTick;
   }

   public float getBoostInterp(float partialTick) {
      return this.prevBoostTimer + (this.boostTimer - this.prevBoostTimer) * partialTick;
   }
}
