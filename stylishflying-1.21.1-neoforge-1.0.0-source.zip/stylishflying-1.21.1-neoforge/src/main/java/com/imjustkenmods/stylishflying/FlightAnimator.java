package com.imjustkenmods.stylishflying;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.core.BlockPos;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

public class FlightAnimator {
   public static void resetModel(Player player, HumanoidModel<?> model) {
      boolean sneak = model.crouching;
      model.head.x = 0.0F;
      model.head.y = sneak ? 4.2F : 0.0F;
      model.head.z = 0.0F;
      model.head.zRot = 0.0F;
      model.body.x = 0.0F;
      model.body.y = sneak ? 3.2F : 0.0F;
      model.body.z = 0.0F;
      model.body.zRot = 0.0F;
      model.rightArm.x = -5.0F;
      model.rightArm.y = sneak ? 5.2F : 2.0F;
      model.rightArm.z = 0.0F;
      model.leftArm.x = 5.0F;
      model.leftArm.y = sneak ? 5.2F : 2.0F;
      model.leftArm.z = 0.0F;
      model.rightLeg.x = -1.9F;
      model.rightLeg.y = sneak ? 12.2F : 12.0F;
      model.rightLeg.z = sneak ? 4.0F : 0.1F;
      model.leftLeg.x = 1.9F;
      model.leftLeg.y = sneak ? 12.2F : 12.0F;
      model.leftLeg.z = sneak ? 4.0F : 0.1F;
   }

   public static void applyBones(Player player, FlightState state, FlightAnimType type, float partialTick, HumanoidModel<?> model) {
      float data0 = FlightState.curve(Mth.lerp(partialTick, state.prevFlightTimer, state.flightTimer));
      float data1 = FlightState.curve(Mth.lerp(partialTick, state.prevBoostTimer, state.boostTimer));
      float landing = FlightState.curve(Mth.lerp(partialTick, state.prevLandingTimer, state.landingTimer));
      float falling = FlightState.curve(Mth.lerp(partialTick, state.prevFallTimer, state.fallTimer));
      float freefalling = FlightState.curve(Mth.lerp(partialTick, state.prevFreefallTimer, state.freefallTimer));
      if (data0 != 0.0F || landing != 0.0F || falling != 0.0F || freefalling != 0.0F) {
         resetModel(player, model);
         Vec3 motion = state.prevMotion.lerp(state.motion, (double)partialTick);
         double motX = motion.x;
         double motZ = motion.z;
         double vel = Math.sqrt(motX * motX + motZ * motZ);
         double clampFactor = vel > 1.0 ? 1.0 / vel : 1.0;
         double nMotX = motX * clampFactor;
         double nMotZ = motZ * clampFactor;
         double bodyYawRad = Math.toRadians((double)Mth.lerp(partialTick, player.yBodyRotO, player.yBodyRot));
         double cosa = Math.cos(bodyYawRad);
         double sina = Math.sin(bodyYawRad);
         double strafe = nMotX * cosa + nMotZ * sina;
         double forward = nMotZ * cosa - nMotX * sina;
         double hover = (double)data0 * (1.0 - (double)data1);
         float suppressWalk = Math.max(data0, falling);
         boolean swinging = player.swingTime > 0 || model.attackTime > 0.0F;
         boolean rightIsSwing = false;
         boolean leftIsSwing = false;
         if (swinging) {
            boolean mainIsRight = player.getMainArm() == HumanoidArm.RIGHT;
            boolean swingIsMain = player.swingingArm == InteractionHand.MAIN_HAND;
            rightIsSwing = swingIsMain == mainIsRight;
            leftIsSwing = !rightIsSwing;
         }

         model.rightArm.xRot *= rightIsSwing ? 1.0F : 1.0F - suppressWalk;
         model.rightArm.yRot *= rightIsSwing ? 1.0F : 1.0F - suppressWalk;
         model.rightArm.zRot *= rightIsSwing ? 1.0F : 1.0F - suppressWalk;
         model.leftArm.xRot *= leftIsSwing ? 1.0F : 1.0F - suppressWalk;
         model.leftArm.yRot *= leftIsSwing ? 1.0F : 1.0F - suppressWalk;
         model.leftArm.zRot *= leftIsSwing ? 1.0F : 1.0F - suppressWalk;
         model.rightLeg.xRot *= 1.0F - suppressWalk;
         model.rightLeg.yRot *= 1.0F - suppressWalk;
         model.rightLeg.zRot *= 1.0F - suppressWalk;
         model.leftLeg.xRot *= 1.0F - suppressWalk;
         model.leftLeg.yRot *= 1.0F - suppressWalk;
         model.leftLeg.zRot *= 1.0F - suppressWalk;
         model.head.xRot = Mth.lerp(data1, model.head.xRot, (float)Math.toRadians(-40.0));
         float hoverf = (float)hover;
         switch (type) {
            case HORIZONTAL_ARMS_FORWARD:
            case HORIZONTAL_ARMS_FORWARD_VARIANT_A:
            case HORIZONTAL_ARMS_FORWARD_VARIANT_B:
               hoverDefault(hoverf, data0, vel, strafe, forward, model);
               break;
            case VERTICAL_ARMS_DOWN:
            case VERTICAL_ARMS_DOWN_VARIANT_A:
               hoververtical_arms_down(hoverf, data0, vel, strafe, forward, model);
               break;
            case HORIZONTAL_ARMS_BACK:
               hoverPropelled(hoverf, data0, vel, strafe, forward, model);
               break;
            case VERTICAL_ARMS_OUT:
               hoverLevitate(hoverf, data0, vel, strafe, forward, model);
               break;
            case VERTICAL_ARMS_FORWARD:
               hoverPropelled(hoverf, data0, vel, strafe, forward, model);
               break;
            case SURFING_POSTURE:
               hoverSurfingPosture(hoverf, data0, vel, strafe, forward, model);
         }

         float idleFade = 1.0F - FlightState.curve((float)Math.min(1.5 * vel, 1.0));
         if (idleFade > 0.0F) {
            applyIdleBones(player, type, partialTick, idleFade, model);
         }

         if (data1 > 0.0F) {
            Vec3 look = player.getViewVector(partialTick);
            double lookX = look.x;
            double lookZ = look.z;
            double dir = Math.sqrt(lookX * lookX + lookZ * lookZ);
            double d = Math.acos(Mth.clamp(dir > 0.0 && vel > 0.0 ? (motX * lookX + motZ * lookZ) / vel / dir : 1.0, -1.0, 1.0));
            double d1 = Math.signum(motX * lookZ - motZ * lookX);
            switch (type) {
               case HORIZONTAL_ARMS_FORWARD:
                  boostArmsForward(data1, vel, d, d1, model);
                  break;
               case HORIZONTAL_ARMS_FORWARD_VARIANT_A:
                  boostHorizontalArmsForwardVariantA(data1, vel, d, d1, model);
                  break;
               case HORIZONTAL_ARMS_FORWARD_VARIANT_B:
                  boostHorizontalArmsForwardVariantB(data1, vel, d, d1, model);
                  break;
               case VERTICAL_ARMS_DOWN:
                  boostvertical_arms_down(data1, vel, d, d1, model);
                  break;
               case VERTICAL_ARMS_DOWN_VARIANT_A:
                  boostVerticalArmsDownVariantA(data1, vel, d, d1, model);
                  break;
               case HORIZONTAL_ARMS_BACK:
                  boosthorizontal_arms_back(data1, vel, d, d1, model);
               case VERTICAL_ARMS_OUT:
               default:
                  break;
               case VERTICAL_ARMS_FORWARD:
                  boostDefault(data1, vel, d, d1, model);
                  break;
               case SURFING_POSTURE:
                  boostSurfingPosture(data1, vel, d, d1, model);
            }
         }

         if (falling > 0.0F && landing == 0.0F) {
            applyFallingBones(falling, model, player, partialTick);
         }

         if (freefalling > 0.0F && landing == 0.0F) {
            float bracing = FlightState.curve(Mth.lerp(partialTick, state.prevBraceTimer, state.braceTimer));
            float effectiveStarfish = freefalling * (1.0F - bracing);
            if (effectiveStarfish > 0.0F) {
               applyFreefallBones(effectiveStarfish, model, player, partialTick);
            }

            if (bracing > 0.0F) {
               applyLandingBones(bracing, model, player);
            }
         }

         if (landing > 0.0F) {
            applyLandingBones(landing, model, player);
         }

         model.hat.copyFrom(model.head);
         if (model instanceof PlayerModel playerModel) {
            playerModel.jacket.copyFrom(playerModel.body);
            playerModel.leftSleeve.copyFrom(playerModel.leftArm);
            playerModel.rightSleeve.copyFrom(playerModel.rightArm);
            playerModel.leftPants.copyFrom(playerModel.leftLeg);
            playerModel.rightPants.copyFrom(playerModel.rightLeg);
         }
      }
   }

   private static void hoverDefault(float hover, float data0, double vel, double strafe, double forward, HumanoidModel<?> model) {
      double x = (double)hover * Math.min(2.0 * vel, 1.0);
      double sn = strafe * x;
      double fn = forward * x;
      double adz = Math.abs(fn);
      model.head.xRot = model.head.xRot - (float)toRad(15.0 * clamp(fn, -2.0, 2.0));
      model.rightArm.xRot += (float)(0.1 * fn + 0.1 * sn);
      model.rightArm.zRot = model.rightArm.zRot + (float)(0.1 * adz + 0.2 * sn + toRad(3.0) * (double)data0);
      model.leftArm.xRot += (float)(0.1 * fn - 0.1 * sn);
      model.leftArm.zRot = model.leftArm.zRot - (float)(0.1 * adz - 0.2 * sn + toRad(3.0) * (double)data0);
      model.rightLeg.xRot += (float)(0.3 * fn);
      model.rightLeg.zRot += (float)(0.05 * adz + 0.4 * sn);
      model.leftLeg.xRot += (float)(0.2 * fn);
      model.leftLeg.zRot -= (float)(0.05 * adz - 0.4 * sn);
   }

   private static void hoververtical_arms_down(float hover, float data0, double vel, double strafe, double forward, HumanoidModel<?> model) {
      double x = (double)hover * Math.min(2.0 * vel, 1.0);
      double sn = strafe * x;
      double fn = forward * x;
      double adx = Math.abs(sn);
      double adz = Math.abs(fn);
      model.head.xRot = model.head.xRot - (float)toRad(30.0 * clamp(fn, -2.0, 2.0));
      model.rightArm.xRot += (float)(0.2 * fn - 0.4 * adx);
      model.rightArm.zRot = model.rightArm.zRot + (float)(0.1 * adz + 0.4 * sn + toRad(3.0) * (double)data0);
      model.leftArm.xRot += (float)(0.2 * fn - 0.4 * adx);
      model.leftArm.zRot = model.leftArm.zRot - (float)(0.1 * adz - 0.4 * sn + toRad(3.0) * (double)data0);
      model.rightLeg.xRot += (float)(0.3 * fn);
      model.rightLeg.zRot += (float)(0.05 * adz + 0.4 * sn);
      model.leftLeg.xRot += (float)(0.2 * fn);
      model.leftLeg.zRot -= (float)(0.05 * adz - 0.4 * sn);
   }

   private static void hoverLevitate(float hover, float data0, double vel, double strafe, double forward, HumanoidModel<?> model) {
      double x = (double)hover * Math.min(2.0 * vel, 1.0);
      double sn = strafe * x;
      double fn = forward * x;
      double adz = Math.abs(fn);
      model.head.xRot = model.head.xRot - (float)toRad(30.0 * clamp(fn, -2.0, 2.0));
      model.rightArm.xRot += (float)(0.2 * fn + 0.1 * sn);
      model.rightArm.zRot = model.rightArm.zRot + (float)(0.1 * adz + 0.2 * sn + toRad(3.0) * (double)data0);
      model.leftArm.xRot += (float)(0.2 * fn - 0.1 * sn);
      model.leftArm.zRot = model.leftArm.zRot - (float)(0.1 * adz - 0.2 * sn + toRad(3.0) * (double)data0);
      model.rightLeg.xRot += (float)(0.3 * fn);
      model.rightLeg.zRot += (float)(0.05 * adz + 0.4 * sn);
      model.leftLeg.xRot += (float)(0.2 * fn);
      model.leftLeg.zRot -= (float)(0.05 * adz - 0.4 * sn);
   }

   private static void hoverPropelled(float hover, float data0, double vel, double strafe, double forward, HumanoidModel<?> model) {
      double x = (double)hover * Math.min(2.0 * vel, 1.0);
      double sn = strafe * x;
      double fn = forward * x;
      double adz = Math.abs(fn);
      model.head.xRot = model.head.xRot - (float)toRad(30.0 * clamp(fn, -2.0, 2.0));
      model.rightArm.xRot += (float)(0.1 * fn + 0.1 * sn);
      model.rightArm.zRot = model.rightArm.zRot + (float)(0.1 * adz + 0.2 * sn + toRad(3.0) * (double)data0);
      model.leftArm.xRot += (float)(0.1 * fn - 0.1 * sn);
      model.leftArm.zRot = model.leftArm.zRot - (float)(0.1 * adz - 0.2 * sn + toRad(3.0) * (double)data0);
      model.rightLeg.xRot += (float)(0.3 * fn);
      model.rightLeg.zRot += (float)(0.05 * adz + 0.4 * sn);
      model.leftLeg.xRot += (float)(0.2 * fn);
      model.leftLeg.zRot -= (float)(0.05 * adz - 0.4 * sn);
   }

   private static void boostArmsForward(float data1, double vel, double d, double d1, HumanoidModel<?> model) {
      double x = Math.min(vel, 1.0) * (double)data1 * d1 * d / 2.5;
      model.head.xRot = model.head.xRot - (float)(toRad(10.0) * (double)data1);
      model.rightArm.xRot = model.rightArm.xRot - (float)(toRad(165.0) * (double)data1 + 0.5 * x);
      model.rightArm.yRot = model.rightArm.yRot + (float)(toRad(15.0) * (double)data1);
      model.rightArm.zRot = model.rightArm.zRot + (float)(toRad(2.0) * (double)data1 - 0.25 * x);
      model.leftArm.xRot = model.leftArm.xRot - (float)(toRad(165.0) * (double)data1 - 0.5 * x);
      model.leftArm.yRot = model.leftArm.yRot - (float)(toRad(15.0) * (double)data1);
      model.leftArm.zRot = model.leftArm.zRot - (float)(toRad(2.0) * (double)data1 + 0.25 * x);
      model.rightLeg.xRot = model.rightLeg.xRot + (float)(toRad(15.0) * (double)data1 + 0.3 * x);
      model.rightLeg.yRot = model.rightLeg.yRot + (float)(toRad(2.0) * (double)data1);
      model.rightLeg.zRot = model.rightLeg.zRot + (float)(toRad(3.0) * (double)data1);
      model.leftLeg.xRot = model.leftLeg.xRot + (float)(toRad(15.0) * (double)data1 - 0.3 * x);
      model.leftLeg.yRot = model.leftLeg.yRot - (float)(toRad(2.0) * (double)data1);
      model.leftLeg.zRot = model.leftLeg.zRot - (float)(toRad(3.0) * (double)data1);
   }

   private static void boostvertical_arms_down(float data1, double vel, double d, double d1, HumanoidModel<?> model) {
      double x = Math.min(vel, 1.0) * (double)data1 * d1 * d / 2.5;
      model.rightArm.xRot = model.rightArm.xRot + (float)(toRad(15.0) * (double)data1 + x);
      model.rightArm.zRot = model.rightArm.zRot + (float)(toRad(10.0) * (double)data1);
      model.leftArm.xRot = model.leftArm.xRot + (float)(toRad(15.0) * (double)data1 - x);
      model.leftArm.zRot = model.leftArm.zRot - (float)(toRad(10.0) * (double)data1);
      model.rightLeg.xRot = model.rightLeg.xRot + (float)(toRad(15.0) * (double)data1 + 0.3 * x);
      model.leftLeg.xRot = model.leftLeg.xRot + (float)(toRad(15.0) * (double)data1 - 0.3 * x);
   }

   private static void boosthorizontal_arms_back(float data1, double vel, double d, double d1, HumanoidModel<?> model) {
      double x = Math.min(vel, 1.0) * (double)data1 * d1 * d / 2.5;
      model.rightArm.xRot = model.rightArm.xRot + (float)(toRad(15.0) * (double)data1 + 0.2 * x - Math.abs(0.3 * x));
      model.rightArm.yRot = model.rightArm.yRot + (float)(toRad(8.0) * (double)data1);
      model.rightArm.zRot = model.rightArm.zRot + (float)(toRad(10.0) * (double)data1);
      model.leftArm.xRot = model.leftArm.xRot + (float)(toRad(15.0) * (double)data1 - 0.2 * x - Math.abs(0.3 * x));
      model.leftArm.yRot = model.leftArm.yRot - (float)(toRad(8.0) * (double)data1);
      model.leftArm.zRot = model.leftArm.zRot - (float)(toRad(10.0) * (double)data1);
      model.rightLeg.xRot = model.rightLeg.xRot + (float)(toRad(15.0) * (double)data1 + 0.3 * x);
      model.rightLeg.yRot = model.rightLeg.yRot + (float)(toRad(2.0) * (double)data1);
      model.rightLeg.zRot = model.rightLeg.zRot + (float)(toRad(3.0) * (double)data1);
      model.leftLeg.xRot = model.leftLeg.xRot + (float)(toRad(15.0) * (double)data1 - 0.3 * x);
      model.leftLeg.yRot = model.leftLeg.yRot - (float)(toRad(2.0) * (double)data1);
      model.leftLeg.zRot = model.leftLeg.zRot - (float)(toRad(3.0) * (double)data1);
   }

   private static void boostDefault(float data1, double vel, double d, double d1, HumanoidModel<?> model) {
      double x = Math.min(vel, 1.0) * (double)data1 * d1 * d / 2.5;
      model.head.xRot = model.head.xRot - (float)(toRad(10.0) * (double)data1);
      model.rightArm.xRot = model.rightArm.xRot + (float)(toRad(15.0) * (double)data1 + x);
      model.rightArm.yRot = model.rightArm.yRot + (float)(toRad(8.0) * (double)data1);
      model.rightArm.zRot = model.rightArm.zRot + (float)(toRad(10.0) * (double)data1);
      model.leftArm.xRot = model.leftArm.xRot + (float)(toRad(15.0) * (double)data1 - x);
      model.leftArm.yRot = model.leftArm.yRot - (float)(toRad(8.0) * (double)data1);
      model.leftArm.zRot = model.leftArm.zRot - (float)(toRad(10.0) * (double)data1);
      model.rightLeg.xRot = model.rightLeg.xRot + (float)(toRad(15.0) * (double)data1 + 0.3 * x);
      model.rightLeg.yRot = model.rightLeg.yRot + (float)(toRad(2.0) * (double)data1);
      model.rightLeg.zRot = model.rightLeg.zRot + (float)(toRad(3.0) * (double)data1);
      model.leftLeg.xRot = model.leftLeg.xRot + (float)(toRad(15.0) * (double)data1 - 0.3 * x);
      model.leftLeg.yRot = model.leftLeg.yRot - (float)(toRad(2.0) * (double)data1);
      model.leftLeg.zRot = model.leftLeg.zRot - (float)(toRad(3.0) * (double)data1);
   }

   private static void applyIdleBones(Player player, FlightAnimType type, float partialTick, float idleFade, HumanoidModel<?> model) {
      float tick = (float)player.tickCount + partialTick;
      switch (type) {
         case HORIZONTAL_ARMS_FORWARD: {
            float wobble = 0.2F * idleFade * (float)Math.sin((double)(tick * 0.1F));
            float x = idleFade + wobble;
            model.head.xRot = model.head.xRot - (float)toRad(3.5 * (double)idleFade - (double)(5.0F * wobble));
            model.head.yRot = model.head.yRot - (float)toRad((double)(10.0F * idleFade));
            model.rightLeg.xRot = model.rightLeg.xRot + (float)toRad((double)(20.0F * x));
            model.rightLeg.yRot = model.rightLeg.yRot + (float)toRad((double)(5.0F * idleFade));
            model.leftLeg.xRot = model.leftLeg.xRot + (float)toRad((double)(5.0F * idleFade - 15.0F * wobble));
            model.leftLeg.yRot = model.leftLeg.yRot - (float)toRad((double)(8.0F * idleFade));
            model.rightArm.xRot = model.rightArm.xRot - (float)toRad((double)(10.0F * idleFade) + 0.1 * (double)wobble);
            model.rightArm.yRot = model.rightArm.yRot + (float)toRad((double)(10.0F * idleFade));
            model.rightArm.zRot = model.rightArm.zRot + (float)toRad((double)(6.0F * x));
            model.leftArm.xRot = model.leftArm.xRot + (float)toRad((double)(5.0F * idleFade) + 0.08 * (double)wobble);
            model.leftArm.yRot = model.leftArm.yRot - (float)toRad((double)(20.0F * idleFade));
            model.leftArm.zRot = model.leftArm.zRot - (float)toRad((double)(10.0F * x));
            break;
         }
         case HORIZONTAL_ARMS_FORWARD_VARIANT_A:
         case HORIZONTAL_ARMS_FORWARD_VARIANT_B: {
            float d1 = 0.2F * idleFade * (float)Math.sin((double)(tick * 0.1F));
            model.head.xRot = model.head.xRot - (float)toRad(3.5 * (double)idleFade - (double)(5.0F * idleFade));
            model.head.yRot = model.head.yRot - (float)toRad((double)(10.0F * idleFade));
            float x = idleFade + d1;
            model.rightLeg.xRot = model.rightLeg.xRot + (float)toRad((double)(20.0F * x));
            model.rightLeg.yRot = model.rightLeg.yRot + (float)toRad((double)(5.0F * idleFade));
            model.rightLeg.x -= 0.3F * idleFade;
            model.rightLeg.y -= x;
            model.rightLeg.z -= 2.5F * (idleFade + 1.5F * d1);
            model.leftLeg.xRot = model.leftLeg.xRot + (float)toRad((double)(5.0F * idleFade - 15.0F * d1));
            model.leftLeg.yRot = model.leftLeg.yRot - (float)toRad((double)(8.0F * idleFade));
            model.leftLeg.x += 0.1F * idleFade;
            model.leftLeg.y -= 0.5F * x;
            model.leftLeg.z -= idleFade;
            model.rightArm.xRot = model.rightArm.xRot - ((float)toRad((double)(10.0F * idleFade)) + 0.1F * d1);
            model.rightArm.yRot = model.rightArm.yRot + (float)toRad((double)(10.0F * idleFade));
            model.rightArm.zRot = model.rightArm.zRot + (float)toRad((double)(6.0F * x));
            model.leftArm.xRot = model.leftArm.xRot + (float)toRad((double)(5.0F * idleFade)) + 0.08F * d1;
            model.leftArm.yRot = model.leftArm.yRot - (float)toRad((double)(20.0F * idleFade));
            model.leftArm.zRot = model.leftArm.zRot - (float)toRad((double)(10.0F * x));
            break;
         }
         case VERTICAL_ARMS_DOWN:
         case VERTICAL_ARMS_OUT: {
            float wobble2 = idleFade * (float)Math.sin((double)(tick * 0.1F));
            float wobble4 = idleFade * (float)Math.sin((double)(tick * 0.2F));
            float wobble2p05 = idleFade * (float)Math.sin((double)(tick * 0.1F) + (Math.PI / 2));
            model.head.xRot = model.head.xRot - (float)toRad(0.5 * (double)wobble2);
            model.head.zRot = (float)(-toRad(0.4 * (double)wobble2p05));
            model.rightArm.xRot = model.rightArm.xRot - (float)toRad(1.5 * (double)wobble4 * (double)wobble2);
            model.leftArm.xRot = model.leftArm.xRot + (float)toRad(1.5 * (double)wobble4 * (double)wobble2p05);
            model.rightArm.zRot = model.rightArm.zRot + (float)toRad((double)(4.0F * idleFade + 2.0F * wobble2));
            model.leftArm.zRot = model.leftArm.zRot - (float)toRad((double)(4.0F * idleFade + 2.0F * wobble2));
            model.rightLeg.xRot = model.rightLeg.xRot + (float)toRad((double)(2.0F * wobble4 * wobble2));
            model.leftLeg.xRot = model.leftLeg.xRot - (float)toRad((double)(2.0F * wobble4 * wobble2p05));
            break;
         }
         case VERTICAL_ARMS_DOWN_VARIANT_A: {
            float d1 = 0.2F * idleFade * (float)Math.sin((double)(tick * 0.1F));
            float x = idleFade + d1;
            model.head.xRot = model.head.xRot - (float)toRad(3.5 * (double)idleFade - (double)(5.0F * idleFade));
            model.head.yRot = model.head.yRot - (float)toRad((double)(10.0F * idleFade));
            model.leftLeg.xRot = model.leftLeg.xRot + (float)toRad((double)(20.0F * x));
            model.leftLeg.yRot = model.leftLeg.yRot - (float)toRad((double)(5.0F * idleFade));
            model.leftLeg.x += 0.3F * idleFade;
            model.leftLeg.y -= x;
            model.leftLeg.z -= 2.5F * (idleFade + 1.5F * d1);
            model.rightLeg.xRot = model.rightLeg.xRot + (float)toRad((double)(5.0F * idleFade - 15.0F * d1));
            model.rightLeg.yRot = model.rightLeg.yRot + (float)toRad((double)(8.0F * idleFade));
            model.rightLeg.x -= 0.1F * idleFade;
            model.rightLeg.y -= 0.5F * x;
            model.rightLeg.z -= idleFade;
            model.rightArm.xRot = model.rightArm.xRot - ((float)toRad((double)(10.0F * idleFade)) + 0.1F * d1);
            model.rightArm.yRot = model.rightArm.yRot + (float)toRad((double)(10.0F * idleFade));
            model.rightArm.zRot = model.rightArm.zRot + (float)toRad((double)(6.0F * x));
            model.leftArm.xRot = model.leftArm.xRot + (float)toRad((double)(5.0F * idleFade)) + 0.08F * d1;
            model.leftArm.yRot = model.leftArm.yRot - (float)toRad((double)(20.0F * idleFade));
            model.leftArm.zRot = model.leftArm.zRot - (float)toRad((double)(10.0F * x));
            break;
         }
         case HORIZONTAL_ARMS_BACK: {
            float wobble = 0.2F * idleFade * (float)Math.sin((double)(tick * 0.1F));
            float wobble2 = idleFade * (float)Math.sin((double)(tick * 0.1F));
            float wobble2p05 = idleFade * (float)Math.sin((double)(tick * 0.1F) + (Math.PI / 2));
            float x = idleFade + wobble;
            model.head.xRot = model.head.xRot - (float)toRad(0.5 * (double)wobble2 + (double)(2.0F * idleFade));
            model.head.zRot = (float)(-toRad(0.4 * (double)wobble2p05));
            model.rightLeg.xRot = model.rightLeg.xRot + (float)toRad((double)(20.0F * x));
            model.rightLeg.yRot = model.rightLeg.yRot + (float)toRad((double)(5.0F * idleFade));
            model.leftLeg.xRot = model.leftLeg.xRot + (float)toRad((double)(5.0F * idleFade - 15.0F * wobble));
            model.leftLeg.yRot = model.leftLeg.yRot - (float)toRad((double)(8.0F * idleFade));
            model.rightArm.xRot = model.rightArm.xRot - (float)toRad((double)(6.0F * idleFade) + 0.1 * (double)wobble);
            model.rightArm.yRot = model.rightArm.yRot + (float)toRad((double)(10.0F * idleFade));
            model.rightArm.zRot = model.rightArm.zRot + (float)toRad((double)(6.0F * x));
            model.leftArm.xRot = model.leftArm.xRot + (float)toRad((double)(5.0F * idleFade) + 0.08 * (double)wobble);
            model.leftArm.yRot = model.leftArm.yRot - (float)toRad((double)(13.0F * idleFade));
            model.leftArm.zRot = model.leftArm.zRot - (float)toRad((double)(8.0F * x));
            break;
         }
         case VERTICAL_ARMS_FORWARD: {
            float wobble = 0.2F * idleFade * (float)Math.sin((double)(tick * 0.1F));
            model.head.xRot = model.head.xRot + (float)toRad((double)(3.0F * idleFade));
            model.rightLeg.xRot = model.rightLeg.xRot + (float)toRad((double)(6.0F * idleFade - 20.0F * wobble));
            model.rightLeg.yRot = model.rightLeg.yRot + (float)toRad((double)(5.0F * idleFade + 2.0F * wobble));
            model.rightLeg.zRot = model.rightLeg.zRot + (float)toRad((double)(2.0F * idleFade - 2.0F * wobble));
            model.leftLeg.xRot = model.leftLeg.xRot + (float)toRad((double)(10.0F * idleFade + 20.0F * wobble));
            model.leftLeg.yRot = model.leftLeg.yRot - (float)toRad((double)(8.0F * idleFade + 4.0F * wobble));
            model.leftLeg.zRot = model.leftLeg.zRot - (float)toRad((double)(3.0F * idleFade - 2.0F * wobble));
            model.rightArm.xRot = model.rightArm.xRot + (float)toRad((double)(2.0F * idleFade) - 0.2 * (double)wobble);
            model.rightArm.yRot = model.rightArm.yRot + (float)toRad((double)(10.0F * idleFade));
            model.rightArm.zRot = model.rightArm.zRot + (float)toRad(5.0 * ((double)idleFade + 1.5 * (double)wobble));
            model.leftArm.xRot = model.leftArm.xRot + (float)toRad((double)(7.0F * idleFade) + 0.2 * (double)wobble);
            model.leftArm.yRot = model.leftArm.yRot - (float)toRad((double)(10.0F * idleFade));
            model.leftArm.zRot = model.leftArm.zRot - (float)toRad(7.0 * ((double)idleFade + 1.5 * (double)wobble));
            break;
         }
         case SURFING_POSTURE: {
            float d1 = 0.2F * idleFade * (float)Math.sin((double)(tick * 0.1F));
            model.head.xRot = model.head.xRot - (float)toRad(3.5 * (double)idleFade - (double)(5.0F * idleFade));
            model.head.yRot = model.head.yRot - (float)toRad((double)(10.0F * idleFade));
            model.body.yRot = model.body.yRot - (float)toRad((double)(10.0F * idleFade));
            float x = (idleFade + d1) * 1.5F;
            model.rightArm.xRot = model.rightArm.xRot - ((float)toRad((double)(5.0F * idleFade)) + 0.1F * d1);
            model.rightArm.yRot = model.rightArm.yRot + (float)toRad((double)(40.0F * idleFade));
            model.rightArm.zRot = model.rightArm.zRot + (float)toRad((double)(6.0F * x));
            model.leftArm.xRot = model.leftArm.xRot + (float)toRad((double)(5.0F * idleFade)) + 0.08F * d1;
            model.leftArm.yRot = model.leftArm.yRot - (float)toRad((double)(20.0F * idleFade));
            model.leftArm.zRot = model.leftArm.zRot - (float)toRad((double)(6.0F * x));
            model.rightArm.x += 0.4F * idleFade;
            model.leftArm.x -= 0.4F * idleFade;
            model.leftLeg.xRot = model.leftLeg.xRot + (float)toRad(7.5 * (double)idleFade);
            model.leftLeg.yRot = model.leftLeg.yRot - (float)toRad((double)(10.0F * idleFade));
            model.leftLeg.y -= 0.25F * idleFade;
            model.leftLeg.z += 0.25F * idleFade;
         }
      }
   }

   private static void hoverSurfingPosture(float hover, float data0, double vel, double strafe, double forward, HumanoidModel<?> model) {
      double x = (double)hover * Math.min(2.0 * vel, 1.0);
      double sn = strafe * x;
      double fn = forward * x;
      double adz = Math.abs(fn);
      model.rightArm.xRot += (float)(0.1 * fn + 0.1 * sn);
      model.rightArm.zRot = model.rightArm.zRot + (float)(0.1 * adz + 0.2 * sn + toRad(3.0) * (double)data0);
      model.leftArm.xRot += (float)(0.1 * fn - 0.1 * sn);
      model.leftArm.zRot = model.leftArm.zRot - (float)(0.1 * adz - 0.2 * sn + toRad(3.0) * (double)data0);
      model.leftLeg.xRot = model.leftLeg.xRot + (float)toRad(7.5 * (double)hover);
      model.leftLeg.yRot = model.leftLeg.yRot - (float)toRad((double)(10.0F * hover));
      model.leftLeg.y -= 0.25F * hover;
      model.leftLeg.z += 0.25F * hover;
   }

   private static void boostHorizontalArmsForwardVariantA(float data1, double vel, double d, double d1, HumanoidModel<?> model) {
      double x = Math.min(vel, 1.0) * (double)data1 * d1 * d / 2.5;
      model.head.xRot = model.head.xRot - (float)(toRad(10.0) * (double)data1);
      model.rightArm.xRot = model.rightArm.xRot - (float)(toRad(165.0) * (double)data1 + 0.5 * Math.abs(x));
      model.rightArm.yRot = model.rightArm.yRot + (float)(toRad(8.0) * (double)data1);
      model.rightArm.zRot = model.rightArm.zRot - (float)(toRad(4.0) * (double)data1 + 0.5 * Math.abs(x));
      model.leftArm.xRot = model.leftArm.xRot + (float)(toRad(5.0) * (double)data1 + 0.5 * x);
      model.leftArm.yRot = model.leftArm.yRot - (float)(toRad(18.0) * (double)data1);
      model.leftArm.zRot = model.leftArm.zRot - (float)(toRad(15.0) * (double)data1);
      model.rightLeg.xRot = model.rightLeg.xRot + (float)(toRad(15.0) * (double)data1 + 0.3 * x);
      model.rightLeg.yRot = model.rightLeg.yRot + (float)(toRad(2.0) * (double)data1);
      model.rightLeg.zRot = model.rightLeg.zRot + (float)(toRad(3.0) * (double)data1);
      model.leftLeg.x += 1.5F * data1;
      model.leftLeg.y -= 3.0F * data1;
      model.leftLeg.z -= 4.0F * data1;
      model.leftLeg.xRot = model.leftLeg.xRot + (float)(toRad(30.0) * (double)data1 - 0.3 * x);
      model.leftLeg.yRot = model.leftLeg.yRot - (float)(toRad(6.0) * (double)data1);
      model.leftLeg.zRot = model.leftLeg.zRot + (float)(toRad(6.0) * (double)data1);
   }

   private static void boostHorizontalArmsForwardVariantB(float data1, double vel, double d, double d1, HumanoidModel<?> model) {
      double x = Math.min(vel, 1.0) * (double)data1 * d1 * d / 2.5;
      model.head.xRot = model.head.xRot - (float)(toRad(10.0) * (double)data1);
      model.rightArm.yRot = model.rightArm.yRot + (float)(toRad(8.0) * (double)data1);
      model.rightArm.zRot = model.rightArm.zRot + (float)(toRad(8.0) * (double)data1);
      model.leftArm.yRot = model.leftArm.yRot - (float)(toRad(8.0) * (double)data1);
      model.leftArm.zRot = model.leftArm.zRot - (float)(toRad(8.0) * (double)data1);
      model.leftArm.xRot = model.leftArm.xRot - (float)(toRad(165.0) * (double)data1);
      model.leftArm.yRot = model.leftArm.yRot - (float)(toRad(40.0) * (double)data1);
      model.leftArm.zRot = model.leftArm.zRot + (float)(toRad(5.0) * (double)data1);
      model.rightArm.xRot = model.rightArm.xRot - (float)(toRad(165.0) * (double)data1);
      model.rightArm.yRot = model.rightArm.yRot + (float)(toRad(40.0) * (double)data1);
      model.rightArm.zRot = model.rightArm.zRot - (float)(toRad(5.0) * (double)data1);
      model.rightLeg.xRot = model.rightLeg.xRot + (float)(toRad(15.0) * (double)data1 + 0.3 * x);
      model.rightLeg.yRot = model.rightLeg.yRot + (float)(toRad(2.0) * (double)data1);
      model.rightLeg.zRot = model.rightLeg.zRot + (float)(toRad(3.0) * (double)data1);
      model.leftLeg.x += 1.5F * data1;
      model.leftLeg.y -= 3.0F * data1;
      model.leftLeg.z -= 4.0F * data1;
      model.leftLeg.xRot = model.leftLeg.xRot + (float)(toRad(30.0) * (double)data1 - 0.3 * x);
      model.leftLeg.yRot = model.leftLeg.yRot - (float)(toRad(6.0) * (double)data1);
      model.leftLeg.zRot = model.leftLeg.zRot + (float)(toRad(6.0) * (double)data1);
   }

   private static void boostVerticalArmsDownVariantA(float data1, double vel, double d, double d1, HumanoidModel<?> model) {
      double x = Math.min(vel, 1.0) * (double)data1 * d1 * d / 2.5;
      model.rightArm.xRot = model.rightArm.xRot + (float)(toRad(30.0) * (double)data1);
      model.rightArm.zRot = model.rightArm.zRot + (float)(toRad(14.0) * (double)data1);
      model.leftArm.xRot = model.leftArm.xRot + (float)(toRad(30.0) * (double)data1);
      model.leftArm.zRot = model.leftArm.zRot - (float)(toRad(14.0) * (double)data1);
      model.rightLeg.xRot = model.rightLeg.xRot + (float)(toRad(42.0) * (double)data1);
      model.rightLeg.zRot += (float)(0.08 * (double)data1 + 0.07 * x);
      model.rightLeg.yRot = model.rightLeg.yRot + (float)(toRad(4.5) * (double)data1);
      model.rightLeg.z -= 3.5F * data1;
      model.rightLeg.y -= 1.5F * data1;
      model.leftLeg.xRot = model.leftLeg.xRot + (float)(toRad(20.0) * (double)data1);
      model.leftLeg.zRot = model.leftLeg.zRot - (float)(toRad(5.08) * (double)data1 - 0.07 * x);
   }

   private static void boostSurfingPosture(float data1, double vel, double d, double d1, HumanoidModel<?> model) {
      float x = (float)(Math.min(vel, 1.0) * (double)data1 * d1 * d / 2.5);
      model.head.xRot = model.head.xRot + (float)toRad((double)(40.0F * data1));
      model.head.y += 0.5F * data1;
      model.body.xRot = model.body.xRot + (float)toRad((double)(60.0F * data1));
      model.leftArm.xRot = model.leftArm.xRot + (float)toRad((double)(60.0F * data1)) + 0.5F * Math.abs(x);
      model.leftArm.zRot = model.leftArm.zRot - (float)toRad((double)(50.0F * data1));
      model.leftArm.z += 2.0F * data1;
      model.rightArm.xRot = model.rightArm.xRot + (float)toRad((double)(60.0F * data1)) + 0.5F * Math.abs(x);
      model.rightArm.zRot = model.rightArm.zRot + (float)toRad(47.5 * (double)data1);
      model.rightArm.z += 2.0F * data1;
      model.leftLeg.xRot = model.leftLeg.xRot + (float)toRad(72.5 * (double)data1);
      model.leftLeg.yRot = model.leftLeg.yRot + (float)toRad(2.5 * (double)data1);
      model.leftLeg.x += 0.4F * data1;
      model.leftLeg.y -= 4.25F * data1;
      model.leftLeg.z += 9.5F * data1;
      model.rightLeg.xRot = model.rightLeg.xRot + (float)toRad(67.5 * (double)data1);
      model.rightLeg.yRot = model.rightLeg.yRot + (float)toRad(2.5 * (double)data1);
      model.rightLeg.zRot = model.rightLeg.zRot - (float)toRad((double)(5.0F * data1));
      model.rightLeg.x -= 1.0F * data1;
      model.rightLeg.y -= 5.25F * data1;
      model.rightLeg.z += 2.5F * data1;
   }

   private static void applyFallingBones(float falling, HumanoidModel<?> model, Player player, float partialTick) {
      float tick = (float)player.tickCount + partialTick;
      float d1 = 0.2F * falling * (float)Math.sin((double)(tick * 0.1F));
      float x = falling + d1;
      model.leftLeg.xRot = model.leftLeg.xRot + (float)toRad((double)(20.0F * x)) * falling;
      model.leftLeg.yRot = model.leftLeg.yRot - (float)toRad((double)(5.0F * falling)) * falling;
      model.leftLeg.x += 0.3F * falling * falling;
      model.leftLeg.y -= x * falling;
      model.leftLeg.z -= 2.5F * (falling + 1.5F * d1) * falling;
      model.rightLeg.xRot = model.rightLeg.xRot + (float)toRad((double)(5.0F * falling - 15.0F * d1)) * falling;
      model.rightLeg.yRot = model.rightLeg.yRot + (float)toRad((double)(8.0F * falling)) * falling;
      model.rightLeg.x -= 0.1F * falling * falling;
      model.rightLeg.y -= 0.5F * x * falling;
      model.rightLeg.z -= falling * falling;
      model.rightArm.xRot = model.rightArm.xRot - (float)toRad(160.0) * falling;
      model.rightArm.zRot = model.rightArm.zRot + (float)toRad(20.0) * falling;
      model.leftArm.xRot = model.leftArm.xRot - (float)toRad(160.0) * falling;
      model.leftArm.zRot = model.leftArm.zRot - (float)toRad(20.0) * falling;
      double groundDist = 15.0;

      for (int i = 0; i <= 15; i++) {
         BlockPos bp = player.blockPosition().below(i);
         if (!player.level().getBlockState(bp).isAir()) {
            groundDist = (double)i + (player.getY() - Math.floor(player.getY()));
            break;
         }
      }
   }

   private static void applyFreefallBones(float falling, HumanoidModel<?> model, Player player, float partialTick) {
      model.head.xRot = Mth.lerp(falling, model.head.xRot, (float) (-Math.PI / 4));
      model.rightArm.xRot = Mth.lerp(falling, model.rightArm.xRot, 0.0F);
      model.rightArm.yRot = Mth.lerp(falling, model.rightArm.yRot, (float)toRad(25.0));
      model.rightArm.zRot = Mth.lerp(falling, model.rightArm.zRot, (float)toRad(33.0));
      model.leftArm.xRot = Mth.lerp(falling, model.leftArm.xRot, 0.0F);
      model.leftArm.yRot = Mth.lerp(falling, model.leftArm.yRot, (float)toRad(-25.0));
      model.leftArm.zRot = Mth.lerp(falling, model.leftArm.zRot, (float)toRad(-33.0));
      model.rightLeg.xRot = Mth.lerp(falling, model.rightLeg.xRot, (float)toRad(10.77));
      model.rightLeg.yRot = Mth.lerp(falling, model.rightLeg.yRot, (float)toRad(5.74));
      model.rightLeg.zRot = Mth.lerp(falling, model.rightLeg.zRot, (float)toRad(21.93));
      model.leftLeg.xRot = Mth.lerp(falling, model.leftLeg.xRot, (float)toRad(15.0));
      model.leftLeg.yRot = Mth.lerp(falling, model.leftLeg.yRot, (float)toRad(-12.0));
      model.leftLeg.zRot = Mth.lerp(falling, model.leftLeg.zRot, (float)toRad(-20.0));
   }

   private static void applyLandingBones(float landing, HumanoidModel<?> model, Player player) {
      model.head.y = Mth.lerp(landing, model.head.y, 5.5F);
      model.head.z = Mth.lerp(landing, model.head.z, -7.0F);
      model.head.xRot = Mth.lerp(landing, model.head.xRot, (float)toRad(55.0));
      model.head.zRot = Mth.lerp(landing, model.head.zRot, 0.0F);
      model.body.y = Mth.lerp(landing, model.body.y, 5.0F);
      model.body.z = Mth.lerp(landing, model.body.z, -6.0F);
      model.body.xRot = Mth.lerp(landing, model.body.xRot, (float)toRad(35.0));
      float bodyY = model.body.yRot;

      while ((double)bodyY > Math.PI) {
         bodyY = (float)((double)bodyY - (Math.PI * 2));
      }

      while ((double)bodyY < -Math.PI) {
         bodyY = (float)((double)bodyY + (Math.PI * 2));
      }

      model.body.yRot = Mth.lerp(landing, bodyY, (float)toRad(10.0));
      model.body.zRot = Mth.lerp(landing, model.body.zRot, 0.0F);
      model.rightArm.x = Mth.lerp(landing, model.rightArm.x, -5.0F);
      model.rightArm.y = Mth.lerp(landing, model.rightArm.y, 7.0F);
      model.rightArm.z = Mth.lerp(landing, model.rightArm.z, -3.5F);
      model.rightArm.xRot = Mth.lerp(landing, model.rightArm.xRot, (float)toRad(75.0));
      model.rightArm.yRot = Mth.lerp(landing, model.rightArm.yRot, (float)toRad(-15.0));
      model.rightArm.zRot = Mth.lerp(landing, model.rightArm.zRot, (float)toRad(20.0));
      model.leftArm.x = Mth.lerp(landing, model.leftArm.x, 5.5F);
      model.leftArm.y = Mth.lerp(landing, model.leftArm.y, 7.0F);
      model.leftArm.z = Mth.lerp(landing, model.leftArm.z, -5.0F);
      model.leftArm.xRot = Mth.lerp(landing, model.leftArm.xRot, (float)toRad(65.0));
      model.leftArm.yRot = Mth.lerp(landing, model.leftArm.yRot, (float)toRad(15.0));
      model.leftArm.zRot = Mth.lerp(landing, model.leftArm.zRot, (float)toRad(-20.0));
      model.rightLeg.x = Mth.lerp(landing, model.rightLeg.x, -2.0F);
      model.rightLeg.y = Mth.lerp(landing, model.rightLeg.y, 15.0F);
      model.rightLeg.z = Mth.lerp(landing, model.rightLeg.z, -0.5F);
      model.rightLeg.xRot = Mth.lerp(landing, model.rightLeg.xRot, (float)toRad(60.0));
      model.rightLeg.yRot = Mth.lerp(landing, model.rightLeg.yRot, (float)toRad(15.0));
      model.rightLeg.zRot = Mth.lerp(landing, model.rightLeg.zRot, (float)toRad(5.0));
      model.leftLeg.x = Mth.lerp(landing, model.leftLeg.x, 4.0F);
      model.leftLeg.y = Mth.lerp(landing, model.leftLeg.y, 12.0F);
      model.leftLeg.z = Mth.lerp(landing, model.leftLeg.z, -4.0F);
      model.leftLeg.xRot = Mth.lerp(landing, model.leftLeg.xRot, (float)toRad(10.0));
      model.leftLeg.yRot = Mth.lerp(landing, model.leftLeg.yRot, (float)toRad(-10.0));
      model.leftLeg.zRot = Mth.lerp(landing, model.leftLeg.zRot, 0.0F);
   }

   // Whole-body lean, wobble, boost pitch and landing crouch, applied to the renderer's pose stack.
   public static void applyBodyTransform(Player player, FlightState state, FlightAnimType animType, float partialTick, PoseStack poseStack) {
      float data0 = FlightState.curve(Mth.lerp(partialTick, state.prevFlightTimer, state.flightTimer));
      float data1 = FlightState.curve(Mth.lerp(partialTick, state.prevBoostTimer, state.boostTimer));
      Vec3 motion = state.prevMotion.lerp(state.motion, (double)partialTick);
      if (data0 > 0.0F) {
         Vec3 look = player.getViewVector(partialTick);
         double motX = motion.x;
         double motZ = motion.z;
         double lookX = look.x;
         double lookZ = look.z;
         double vel_h = Math.sqrt(motX * motX + motZ * motZ);
         double hover = (double)data0 * (1.0 - (double)data1);
         if (hover > 0.0) {
            double bodyYawRad = Math.toRadians((double)Mth.lerp(partialTick, player.yBodyRotO, player.yBodyRot));
            double cosa = Math.cos(bodyYawRad);
            double sina = Math.sin(bodyYawRad);
            double strafe = motX * cosa + motZ * sina;
            double forward = motZ * cosa - motX * sina;
            double leanBase = 30.0;
            if (animType == FlightAnimType.HORIZONTAL_ARMS_FORWARD
               || animType == FlightAnimType.HORIZONTAL_ARMS_FORWARD_VARIANT_A
               || animType == FlightAnimType.HORIZONTAL_ARMS_FORWARD_VARIANT_B
               || animType == FlightAnimType.SURFING_POSTURE) {
               leanBase = 15.0;
            }

            double leanFactor = leanBase * hover * Math.min(1.5 * vel_h, 1.0);
            poseStack.mulPose(Axis.ZP.rotationDegrees((float)(leanFactor * clamp(strafe, -2.0, 2.0))));
            if (animType != FlightAnimType.SURFING_POSTURE) {
               poseStack.mulPose(Axis.XP.rotationDegrees((float)(-leanFactor * clamp(forward, -2.0, 2.0))));
            }
         }

         float idleFade = 1.0F - FlightState.curve((float)Math.min(1.5 * vel_h, 1.0));
         if (idleFade > 0.0F) {
            float tick = (float)player.tickCount + partialTick;
            float wobbleY = 0.15F * idleFade * (float)Math.sin((double)(tick * 0.1F));
            poseStack.translate(0.0F, wobbleY, 0.0F);
            if (animType != FlightAnimType.VERTICAL_ARMS_DOWN && animType != FlightAnimType.VERTICAL_ARMS_OUT) {
               float wobble = 0.2F * idleFade * (float)Math.sin((double)(tick * 0.1F));
               poseStack.mulPose(Axis.XP.rotationDegrees(-3.5F * idleFade + 5.0F * wobble));
            } else {
               float wobble2 = idleFade * (float)Math.sin((double)(tick * 0.1F));
               float wobble2p05 = idleFade * (float)Math.sin((double)(tick * 0.1F) + (Math.PI / 2));
               poseStack.mulPose(Axis.ZP.rotationDegrees(0.6F * wobble2p05));
               poseStack.mulPose(Axis.XP.rotationDegrees(0.6F * wobble2));
            }
         }

         if (data1 > 0.0F) {
            float pitch = Mth.lerp(partialTick, player.xRotO, player.getXRot());
            double dir = Math.sqrt(lookX * lookX + lookZ * lookZ);
            double d = 0.0;
            double d1 = 0.0;
            if (vel_h > 0.001 && dir > 0.001) {
               double dot = (motX * lookX + motZ * lookZ) / vel_h / dir;
               d = Math.acos((double)Mth.clamp((float)dot, -1.0F, 1.0F));
               d1 = Math.signum(motX * lookZ - motZ * lookX);
            }

            double dScaled = d * (double)data1 / Math.toRadians(1.0);
            double x = Math.min(vel_h / 2.0, 1.0) / 2.0;
            float pitchOffset = animType == FlightAnimType.SURFING_POSTURE ? 0.0F : 80.0F;
            poseStack.mulPose(Axis.XP.rotationDegrees(-data1 * (pitch + pitchOffset)));
            poseStack.mulPose(Axis.YP.rotationDegrees((float)(d1 * dScaled)));
            float bankingMult = animType == FlightAnimType.SURFING_POSTURE ? 2.5F : 1.0F;
            poseStack.mulPose(Axis.ZP.rotationDegrees((float)(-d1 * dScaled * x * (double)bankingMult)));
            poseStack.mulPose(Axis.XP.rotationDegrees((float)(dScaled * x)));
            if (animType == FlightAnimType.SURFING_POSTURE) {
               poseStack.translate(0.0, -1.05 * (double)data1, -0.4 * (double)data1);
            } else {
               poseStack.translate(0.0, -0.8 * (double)data1, 0.0);
            }
         }
      }

      float landing = FlightState.curve(Mth.lerp(partialTick, state.prevLandingTimer, state.landingTimer));
      float freefalling = FlightState.curve(Mth.lerp(partialTick, state.prevFreefallTimer, state.freefallTimer));
      if (freefalling > 0.0F && landing == 0.0F) {
         float bracing = Mth.lerp(partialTick, state.prevBraceTimer, state.braceTimer);
         float effectivePitch = freefalling * (1.0F - bracing);
         poseStack.mulPose(Axis.XP.rotationDegrees(-90.0F * effectivePitch));
         poseStack.translate(0.0, 1.0 * (double)effectivePitch, 0.0);
      }

      if (landing > 0.0F) {
         poseStack.translate(0.0, -0.35 * (double)landing, 0.25 * (double)landing);
         poseStack.mulPose(Axis.XP.rotationDegrees(20.0F * landing));
      }
   }

   private static double toRad(double degrees) {
      return Math.toRadians(degrees);
   }

   private static double clamp(double val, double min, double max) {
      return Math.max(min, Math.min(max, val));
   }
}
