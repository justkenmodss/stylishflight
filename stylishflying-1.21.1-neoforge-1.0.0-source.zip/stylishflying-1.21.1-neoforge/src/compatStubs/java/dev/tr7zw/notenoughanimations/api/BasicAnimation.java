// Compile-time stand-in for an optional dependency. Not packed into the jar;
// at runtime the real class from the installed mod is used.
package dev.tr7zw.notenoughanimations.api;

import dev.tr7zw.notenoughanimations.access.PlayerData;
import dev.tr7zw.notenoughanimations.versionless.animations.BodyPart;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.player.AbstractClientPlayer;

public abstract class BasicAnimation {
    public abstract boolean isEnabled();

    public abstract boolean isValid(AbstractClientPlayer entity, PlayerData data);

    public abstract BodyPart[] getBodyParts(AbstractClientPlayer entity, PlayerData data);

    public abstract int getPriority(AbstractClientPlayer entity, PlayerData data);

    public abstract void apply(AbstractClientPlayer entity, PlayerData data, PlayerModel<AbstractClientPlayer> model, BodyPart part, float delta, float tickCounter);
}
