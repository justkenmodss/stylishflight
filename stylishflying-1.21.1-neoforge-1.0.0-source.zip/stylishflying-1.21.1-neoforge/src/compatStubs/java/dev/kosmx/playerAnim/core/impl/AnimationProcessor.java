// Compile-time stand-in for an optional dependency. Not packed into the jar;
// at runtime the real class from the installed mod is used.
package dev.kosmx.playerAnim.core.impl;

import dev.kosmx.playerAnim.api.TransformType;
import dev.kosmx.playerAnim.core.util.Vec3f;

public class AnimationProcessor {
    public boolean isActive() {
        throw new UnsupportedOperationException();
    }

    public Vec3f get3DTransform(String modelName, TransformType type, Vec3f value0) {
        throw new UnsupportedOperationException();
    }
}
