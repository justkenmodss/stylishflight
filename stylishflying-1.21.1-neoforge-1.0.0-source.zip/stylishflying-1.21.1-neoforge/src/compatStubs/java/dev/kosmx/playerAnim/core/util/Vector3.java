// Compile-time stand-in for an optional dependency. Not packed into the jar;
// at runtime the real class from the installed mod is used.
package dev.kosmx.playerAnim.core.util;

public class Vector3<N extends Number> {
    public N getX() {
        throw new UnsupportedOperationException();
    }

    public N getY() {
        throw new UnsupportedOperationException();
    }

    public N getZ() {
        throw new UnsupportedOperationException();
    }
}
