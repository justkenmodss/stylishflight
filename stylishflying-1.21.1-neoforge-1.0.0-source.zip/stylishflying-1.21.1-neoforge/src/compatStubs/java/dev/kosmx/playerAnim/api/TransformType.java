// Compile-time stand-in for an optional dependency. Not packed into the jar;
// at runtime the real class from the installed mod is used.
package dev.kosmx.playerAnim.api;

public enum TransformType {
    POSITION,
    ROTATION,
    BEND,
    SCALE
}
