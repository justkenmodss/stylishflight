// Compile-time stand-in for an optional dependency. Not packed into the jar;
// at runtime the real class from the installed mod is used.
package dev.kosmx.playerAnim.core.util;

public class Vec3f extends Vector3<Float> {
    public Vec3f(float x, float y, float z) {
        throw new UnsupportedOperationException();
    }
}
