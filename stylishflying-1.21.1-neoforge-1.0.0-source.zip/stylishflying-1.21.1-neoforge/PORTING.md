# Development notes

Stylish Flying is a fork of Enhanced Flight 1.0.6 by CheatyBlack (Forge 1.20.1). It started as a NeoForge 1.21.1
port rebuilt from the compiled 1.0.6 jar, keeping the logic as close to the original as possible, and was then
renamed and changed (see the sections from "Animation blending" on).

## Rename
- Mod id `enhancedflight` became `stylishflying`; the package `com.cheatyblack.enhancedflight` became
  `com.imjustkenmods.stylishflying`; the main class `EnhancedFlight` became `StylishFlying`.
- Assets, the mixin config, config file names, tags, item ids, key bindings, packet ids and the persistent-data keys
  all use the new id. Nothing reads the old names, so it can be installed next to Enhanced Flight without clashing
  (though running both would double up the animations).

## Build
- ModDevGradle 2.0.147, NeoForge 21.1.251, Parchment 2024.11.17, Java 21.
- `neoforge.mods.toml` is generated from `src/main/templates`, with values from `gradle.properties`.
- `LICENSE` is packed into the jar as `LICENSE_stylishflying`.

## Mod setup
- `StylishFlying` (formerly `EnhancedFlight`) takes `(IEventBus, ModContainer)` and registers configs with `modContainer.registerConfig`.
- `ForgeConfigSpec` became `ModConfigSpec`. The server config keeps its 12 sections in the original order.
- Items and the creative tab use `DeferredRegister.Items` / `DeferredItem` / `DeferredHolder`.
- `ForgeRegistries` lookups became `BuiltInRegistries`; `new ResourceLocation(...)` became
  `ResourceLocation.fromNamespaceAndPath` / `tryParse`.

## Networking
The SimpleChannel packets became `CustomPacketPayload` records with a `StreamCodec`, registered in
`RegisterPayloadHandlersEvent` (`ModNetworking`):
- `ServerboundBoostPacket` (client to server)
- `ClientboundSyncFlightPacket`, `ClientboundSyncBoostPacket`, `ClientboundLandingVfxPacket` (server to clients)

Sending uses `PacketDistributor.sendToServer`, `sendToPlayer`, `sendToPlayersTrackingEntity` and
`sendToPlayersTrackingEntityAndSelf`.

## Events
- `TickEvent.PlayerTickEvent` became `PlayerTickEvent.Post`; `TickEvent.ClientTickEvent` became `ClientTickEvent.Post`.
- `LivingDamageEvent` became `LivingDamageEvent.Post`.
- The HUD overlay is registered through `RegisterGuiLayersEvent` as `stylishflying:stylishflying_hud`.

## Items
- `ArmorItem` takes a `Holder<ArmorMaterial>`. Durability is set with
  `ArmorItem.Type.CHESTPLATE.getDurability(multiplier)` (diamond 33, iron 15, leather 5, gold 7, netherite 37).
- `onArmorTick` no longer exists; `FlightArmorItem` uses `inventoryTick` and checks the chest slot.
- `hurtAndBreak` takes the equipment slot instead of a break callback.
- The NBT check reads `DataComponents.CUSTOM_DATA`.
- Energy uses `Capabilities.EnergyStorage.ITEM`.
- Effect ids come from the effect holder's registry key.

## Curios
Still accessed by reflection, so Curios stays optional. 1.21 API:
`CuriosApi.getCuriosInventory(LivingEntity)` returns `Optional<ICuriosItemHandler>`, then `getEquippedCurios()`
returns an `IItemHandler`.

## Mixins
- `MixinPlayer`: `Player.causeFallDamage` now calls `mayFly()` (abilities flag or the creative flight attribute)
  instead of reading `Abilities.mayfly`. The redirect target changed from the field to that method call.
- `MixinPlayerRenderer`: `setupRotations` gained a `float scale` parameter (`...PoseStack;FFFF)V`).
- `MixinPlayerModel`: `HumanoidModel.setupAnim` is unchanged.
- No refmap is needed, since NeoForge 1.21.1 runs on Mojang names.

## Animation blending and compatibility (1.1.0)
Order each frame: `PlayerRenderer.setupRotations` (our TAIL) runs before `HumanoidModel.setupAnim` (our TAIL), then
`PlayerModel.setupAnim` continues and NEA, playerAnimator and WATUT pose on top.

- `MixinPlayerRenderer` builds the body transform on an empty `PoseStack` (`FlightAnimator.applyBodyTransform`), blends
  it as a rigid transform (`PoseBlender.lerp`: slerp rotation, lerp translation), then multiplies it in. It also
  decides the per-frame blend values: the crossfade start and how much to yield to other animations.
- `MixinPlayerModel` captures the model as it arrived, applies the flight bones, restores busy arms (rotated by the
  head's pitch change), blends by the yield weight and the crossfade, and writes the result back.
- The pose stays applied while any flight timer is above zero, so it fades out instead of cutting off.
- Crossfades (`FlightState.fadeRequest`) start on a hard landing and when the flight style changes.
- Bones use the real partial tick (`ageInTicks - tickCount`) instead of a fixed 1.0.

Optional mods live in `compat/` and are only class-loaded when present:
- `PlayerAnimatorCompat` asks the player's animation stack for each part's transform with a marker value; a changed
  value means the part is animated. `body`/legs count as full-body, `torso`/head/arms as upper-body.
- `NeaCompat` registers a NEA `BasicAnimation` with priority 3150 that claims the body parts the flight pose is
  drawing (not busy arms) and changes nothing, so NEA leaves those parts alone. Registered on the first client tick.
- `src/compatStubs` holds compile-only copies of the few API signatures used. They are not packed into the jar, so the
  build needs neither mod.

Mixin note: calling `clone()` on an array inside a mixin method crashes the Mixin transformer; keep that in normal classes.

## HUD
- The bars were drawn with `GuiGraphics.fill`. They are now GUI sprites under `textures/gui/sprites/hud/`, drawn with
  `blitSprite`, so they go through the GUI atlas and resource packs can override them.
- The fill sprite is drawn at full size inside a scissor rectangle cut at the fill level, so it works with any sprite
  scaling (`blitSprite`'s partial-UV variant only crops stretched sprites).
- The default PNGs reproduce the old colors pixel for pixel. Their `.mcmeta` files use `nine_slice`: background
  border 1/2/1/1 (left/top/right/bottom, the top keeps the lighter inner row), fill border top 1 (the highlight row).
- `HudAnchor` places a bar's outer frame; `HOTBAR` keeps the original position math and holds the bottom edge in place
  when the height changes.

## Flight access
- `CommonEventHandler.hasFlightAccess` is the one check for "the flight features apply": creative, spectator,
  `Player.mayFly()` (which includes NeoForge's creative flight attribute), or a flight item when `items_grant_flight`
  is on. No-fall, the landing/freefall poses, boost, overheat and the shockwave use it. Before, the client checked
  `Abilities.mayfly` and the server checked flight items, so attribute flight was missed on the client.
- With `items_grant_flight` off, the server never sets `mayfly`. The cleanup branch still removes flight it gave
  earlier (the `stylishflying_granted_flight` tag) if the option is turned off later, and the dimension restriction only strips flight that
  came from items.
- `enable_takeoff`, `items_grant_flight`, `enable_fall_animation`, `enable_landing_animation` and `enable_landing_shockwave` default to false.

## Config copy
`TestConfigCopy` copied `defaultconfigs` into `<world>/serverconfig`. NeoForge 1.21.1 keeps server configs in
`config/`, so this step no longer has any effect. It is kept so the behaviour can be restored if needed.

## Tested
- Dedicated server: starts cleanly, items register, the server config is generated with all sections.
- Client: all three mixins apply, flight, boost, the overheat HUD and third-person rendering work.
