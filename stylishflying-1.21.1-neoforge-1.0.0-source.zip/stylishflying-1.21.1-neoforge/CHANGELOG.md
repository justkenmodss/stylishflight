# Changelog

## Stylish Flying 1.0.0

First release under the new name. Stylish Flying is a fork of Enhanced Flight by CheatyBlack, continuing from the
NeoForge 1.21.1 port below.

### Renamed
- The mod is now **Stylish Flying**, mod id `stylishflying`. Configs, item ids, tags, key bindings, resource paths and
  network channels all moved from `enhancedflight` to `stylishflying`:
  - `config/enhancedflight-server.toml` is now `config/stylishflying-server.toml` (same for the client config). Copy
    your settings over if you changed them.
  - Item tags are now `stylishflying:*_animations` and `stylishflying:flight_upgrades`.
  - The test chestplates are now `stylishflying:*_chestplate`.
- It can no longer be mistaken for, or clash with, the original Enhanced Flight. Don't install both.

### Added
- Server config option `items_grant_flight` (in `Default Flight Options`). When off, the mod never gives anyone
  flight. Its animations, boost, overheat, landings and no-fall only apply to players who can already fly: creative,
  spectator, or NeoForge's creative flight attribute (which other flight mods use). Flight items, tags and potions then
  only choose the animation style.
- More HUD options in the client config (`UI Positions`), for both the takeoff and the overheat bar:
  - `show_takeoff_bar` / `show_overheat_bar` to hide a bar.
  - `takeoff_bar_anchor` / `overheat_bar_anchor` to pin a bar to a screen corner, edge or the center. `HOTBAR` is the
    default spot. The x/y offsets are added on top.
  - `*_bar_width` / `*_bar_height` to resize the bars.
  - `overheat_bar_always_visible` to keep the overheat bar up while flying even when it is empty.
- The bars are now textures that resource packs can replace
  (`assets/stylishflying/textures/gui/sprites/hud/`, see the README for the list). The defaults look the same as
  before.

### Changed
- New defaults, all `false`: `items_grant_flight`, `enable_takeoff` (sonic takeoff), `enable_fall_animation` (freefall
  pose), `enable_landing_animation` and `enable_landing_shockwave` (superhero landing slam and shockwave). Set them to
  `true` for Enhanced Flight's behavior.
- The flight features now also apply to players flying through NeoForge's creative flight attribute, on both client
  and server.

### Notes
- The stamina mechanic itself is switched on and off with `enable_overheat` in the server config.

---

The entries below are from the NeoForge 1.21.1 port of Enhanced Flight, before the rename.

## Enhanced Flight port 1.1.0

### Added
- Works alongside other player animation mods:
  - **playerAnimator** (Emotecraft, Combat Roll, Better Combat, Iron's Spells 'n Spellbooks): when another mod plays a
    full-body animation (an emote, a roll), the flight pose fades out, lets it play, and fades back in when it ends.
    Animations that only move the arms (spell casts, weapon swings) play on top of the flight pose.
  - **Not Enough Animations**: its falling, elytra and sprinting animations no longer replace the flight pose, while its
    eating, drinking, map and bow animations still play on the arm that is doing them.
  - Arms that are busy keep their own pose while flying: aiming a bow or crossbow, blocking with a shield, eating, and
    Iron's Arms 'n Artifice / Iron's Spells weapon and casting poses. They turn with the head so aiming still lines up.
  - WATUT keeps working as before (it poses the player after Enhanced Flight).
  - None of these mods are required.
- Client config section `Animation Compatibility`:
  - `yield_to_player_animator` (default on): fade out for full-body playerAnimator animations.
  - `yield_to_arm_animations` (default off): also fade out for arm-only animations like spell casts.

### Changed
- Smoother transitions:
  - Stopping flight eases back to the normal pose instead of snapping upright.
  - Hitting the ground blends into the superhero landing instead of jumping straight into it.
  - Switching to armor with a different flight style crossfades between the two styles.
  - Arms, legs and head now move smoothly between ticks instead of updating 20 times a second.

## Enhanced Flight port 1.0.6 - NeoForge 1.21.1

Port of Enhanced Flight 1.0.6 (Forge 1.20.1) to NeoForge for Minecraft 1.21.1. Gameplay, animations, keybinds and
config options are the same as before.

### Changed
- Runs on Minecraft 1.21.1 with NeoForge 21.1.x (built against 21.1.251). Needs Java 21.
- The license in the mod metadata is now MIT, matching the CurseForge page. The old "All Rights Reserved" entry was a
  mistake. The license text is now included in the jar.
- The server config is now in `config/enhancedflight-server.toml` for every world, because NeoForge 1.21.1 no longer
  keeps server configs in `<world>/serverconfig`. Copy your old settings over from there if you had changed them.
- Item tags used in the config moved from `tags/items/` to `tags/item/` (Minecraft 1.21 renamed the folder).
- Item NBT checks in the config now read the item's custom data, since 1.21 items store their data as components.
- Curios support uses the Curios 1.21 API.
- Energy costs use NeoForge's item energy capability.
- The test chestplates have their durability set explicitly, as 1.21 armor materials no longer carry durability. The
  netherite one is fire resistant like other netherite gear.

### Fixed for 1.21.1
- No-fall-damage while flying works with 1.21.1's fall damage check, which now also looks at the creative flight
  attribute.
