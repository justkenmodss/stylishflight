# Stylish Flying
### For NeoForge 1.21.1

Stylish Flying gives creative-style flight 3D animations: full-body flight poses, camera tilting and a speed boost
with a stamina (overheat) bar.

By **imjustkenmods**. A fork of [Enhanced Flight](https://www.curseforge.com/minecraft/mc-mods/enhanced-flight) by
**CheatyBlack** (Forge 1.20.1), ported to NeoForge 1.21.1 and changed:
- It never gives anyone flight by default. It only styles flight you already have (creative, spectator, or NeoForge's
  creative flight attribute).
- The superhero landing, freefall pose and sonic takeoff are off by default.
- It blends with other animation mods and has a customizable, retexturable HUD.

All of Enhanced Flight's features are still there and can be turned back on in the config.

## Requirements
- Minecraft 1.21.1
- NeoForge 21.1.x (built against 21.1.251)
- Java 21
- Optional: [Curios API](https://www.curseforge.com/minecraft/mc-mods/curios) for flight items worn in curio slots

The mod is needed on both the server and the client.

## Installing
1. Install NeoForge 1.21.1 (through the CurseForge app, Prism, the Modrinth app, or the NeoForge installer).
2. Put `stylishflying-neoforge-1.21.1-1.0.0.jar` into the `mods` folder of your instance (or of the server).
3. Start the game.

Stylish Flying uses its own mod id (`stylishflying`), so it does not share configs, items or tags with Enhanced
Flight. Don't install both.

## Controls
| Key | Default | What it does |
| --- | --- | --- |
| Boost | Left Ctrl | Fly faster while flying (builds up heat) |
| Takeoff | Left Shift | Hold on the ground to charge a sonic takeoff (off by default, `enable_takeoff`) |

Both can be changed under Options > Controls > Key Binds > Stylish Flying.

## Who gets the flight features
By default Stylish Flying does not give anyone flight. Its animations, boost, overheat and no-fall apply to players
who can already fly:
- Creative and spectator mode
- NeoForge's creative flight attribute (`neoforge:creative_flight`), which other flight mods use, or any other mod
  that turns on creative-style flight

Set `items_grant_flight = true` in the server config to also let these give survival players flight, like Enhanced
Flight does:
- Any item listed in the server config (`flight_upgrades` or one of the `*_armors` lists) or in a Stylish Flying item
  tag, worn as armor or in a Curios slot
- Flight potion effects listed in the server config
- The test chestplates in the Stylish Flying creative tab

Either way, those items still choose the animation style while flying.

The animation style comes from the item tags `stylishflying:horizontal_arms_forward_animations`,
`stylishflying:vertical_arms_down_animations`, `stylishflying:horizontal_arms_back_animations` and the other
`*_animations` tags, so modded flight items can pick a style with a datapack (`data/stylishflying/tags/item/...`).

## Off by default
These Enhanced Flight features are off in Stylish Flying. Set them to `true` in `config/stylishflying-server.toml` to
turn them back on:
| Option | Feature |
| --- | --- |
| `items_grant_flight` | Flight items, tags and potions give survival players flight |
| `enable_landing_animation` | Superhero landing pose when hitting the ground fast |
| `enable_landing_shockwave` | Landing shockwave (particles, sound, damage, knockback) |
| `enable_fall_animation` | Freefall pose when falling from high up |
| `enable_takeoff` | Sonic takeoff (hold the takeoff key on the ground) |

## Other animation mods
Stylish Flying works together with these, none of them required:
- **playerAnimator** and the mods built on it (Emotecraft, Combat Roll, Better Combat, Iron's Spells 'n Spellbooks):
  full-body animations fade the flight pose out and back in; arm-only animations play on top of it.
- **Not Enough Animations**: the flight pose takes priority over NEA's falling, elytra and sprinting animations, while
  its hand animations (eating, maps, bows) still play.
- **Iron's Arms 'n Artifice** and vanilla aiming/blocking: arms that are using an item keep their pose while flying.
- **WATUT**: works as usual.

## Configuration
- `config/stylishflying-server.toml`: flight speed, costs (durability, energy, hunger), overheat, grounded combat nerf,
  superhero landing, sonic takeoff, kinetic destruction, dimension restrictions and which items or effects give flight.
- `config/stylishflying-client.toml`: the takeoff and overheat bars (see below), and how the flight pose gives way to
  other mods' animations.

## HUD bars
There are two bars:
- **Overheat** (yellow to red): flight stamina, fills while boosting. When it is full you overheat and can't boost
  until it cools down.
- **Sonic Takeoff** (blue): fills while you hold the takeoff key on the ground. Only shows when the takeoff is on.

For each bar, the `UI Positions` section of the client config has:
| Option | What it does |
| --- | --- |
| `show_takeoff_bar` / `show_overheat_bar` | Show or hide the bar |
| `*_bar_anchor` | `HOTBAR` (the default spot), `TOP_LEFT`, `TOP_CENTER`, `TOP_RIGHT`, `MIDDLE_LEFT`, `CENTER`, `MIDDLE_RIGHT`, `BOTTOM_LEFT`, `BOTTOM_CENTER`, `BOTTOM_RIGHT` |
| `*_bar_x` / `*_bar_y` | Offset from the anchor in GUI pixels (positive is right / down) |
| `*_bar_width` / `*_bar_height` | Size of the fill area |
| `overheat_bar_always_visible` | Keep the overheat bar on screen while flying even when it is empty |

The client config reloads while the game is running.

To turn the stamina mechanic itself off, set `enable_overheat = false` in `config/stylishflying-server.toml`.

### Resource pack textures
The bars are GUI sprites, so a resource pack can replace them. Put PNGs at
`assets/stylishflying/textures/gui/sprites/hud/` in the pack:

| Sprite | Used for |
| --- | --- |
| `takeoff_background.png` | Takeoff bar frame and empty part |
| `takeoff_fill.png` | Takeoff charge |
| `takeoff_fill_ready.png` | Flashes when the takeoff is fully charged |
| `overheat_background.png` | Overheat bar frame and empty part |
| `overheat_fill_low.png` | Heat below 50% |
| `overheat_fill_medium.png` | Heat 50% to 80% |
| `overheat_fill_high.png` | Heat above 80% |
| `overheat_fill_overheated.png` | Flashes while overheated |

The background is drawn one pixel larger than the fill area on every side. Fill sprites are drawn at the full bar
size and cut off at the current level, so gradients and patterns stay in place as the bar fills. Scaling is set by an
optional `.png.mcmeta` next to each texture, the same way as vanilla GUI sprites (`stretch`, `tile` or
`nine_slice`). The defaults use `nine_slice`, so they keep a 1-pixel border at any bar size.

## Building from source
```
gradlew build
```
The jar ends up in `build/libs`. Use `gradlew runClient` or `gradlew runServer` to start a development game.

## License
MIT. See [LICENSE](LICENSE). Enhanced Flight is MIT licensed by CheatyBlack; Stylish Flying keeps that license and
its copyright notice.
